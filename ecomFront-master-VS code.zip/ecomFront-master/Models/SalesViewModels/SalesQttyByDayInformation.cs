﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ecomFront.Models.SalesViewModels
{
    public class SalesQttyByDayInformation
    {
        public double Quantity { get; set; }
        public DateTime Date { get; set; }
    }
}
