﻿using ecomFront.Models.PricingViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ecomFront.Models.TrendViewModels
{
    public class WordCloudItem
    {
        public String  text { get; set; }
        public double weight { get; set; }

    }
}
