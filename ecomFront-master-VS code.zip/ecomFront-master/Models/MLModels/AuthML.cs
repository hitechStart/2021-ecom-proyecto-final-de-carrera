﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ecomFront.Models.MLModels
{
    public class AuthML
    {
        public String Access_Token { get; set; }
        public String Token_Type { get; set; }

    }
}
