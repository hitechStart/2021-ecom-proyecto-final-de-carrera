﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ecomFront.Models.AnalisisViewModels
{
    public class EventsIndicator
    {
        public string name { get; set; }
        public double average { get; set; }
        public double difference { get; set; }
        public DateTime fecha { get; set; }

    }
}
