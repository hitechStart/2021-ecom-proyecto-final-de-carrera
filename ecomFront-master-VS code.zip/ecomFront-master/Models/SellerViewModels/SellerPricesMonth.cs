﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ecomFront.Models.SellerViewModels
{
    public class SellerPricesMonth
    {
        public SellerPricesMonth()
        {
        }

        public String month { get; set; }
        public String price { get; set; }

    }
}
