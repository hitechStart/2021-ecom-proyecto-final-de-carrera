﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ecomFront.Common
{
    public static class ItemCondition
    {
        public const string
            Nuevo = "Nuevo",
            Usado = "Usado",
            NoEspecificado = "NoEspecificado";
    }
}
