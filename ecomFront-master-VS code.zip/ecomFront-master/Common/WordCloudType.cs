﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ecomFront.Common
{
    public static class WordCloudType
    {
        public const int
            Publicaciones = 1,
            Ventas = 2,
            Oportunidad = 3;
    }
}
