﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ecomFront.Common
{
    public static class ListingSearchType
    {
        public const int
            VisitasxVentas = 1,
            PreguntasxVentas = 2,
            CantVentas = 3,
            CantVisitas = 4,
            CantPreguntas = 5,
            CantReviews = 6;
    }
}
