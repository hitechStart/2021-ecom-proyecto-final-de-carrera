package ar.edu.unlam.connector.ecom.connectors;

import ar.edu.unlam.connector.ecom.exceptions.ApiException;
import ar.edu.unlam.connector.ecom.utils.JsonUtils;
import org.apache.http.HttpStatus;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import java.util.List;

public enum PaymentClient {
    INSTANCE;

    CloseableHttpClient httpClient = HttpClients.createDefault();

    public List getPaymentMethods (){
        HttpUriRequest request = new HttpGet("https://api.mercadolibre.com/sites/MLA/payment_methods");
        request.setHeader("Content-Type", "application/json");
        CloseableHttpResponse response = null;
        try{
            response = httpClient.execute(request);
            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK){
                String result = EntityUtils.toString(response.getEntity());
                return JsonUtils.INSTANCE.toList(result);
            }
            else{
                throw new ApiException("get.PaymentMethods.failed","Failed to get PaymentMethods from mercadolibre api",HttpStatus.SC_INTERNAL_SERVER_ERROR);
            }
        }
        catch(Exception e){
            throw new ApiException("get.PaymentMethods.failed","Failed to get PaymentMethods from mercadolibre api",HttpStatus.SC_INTERNAL_SERVER_ERROR);
        }
        finally {
            try {
                if (response != null)
                    response.close();
            }
            catch(Exception e){
                throw new ApiException("get.PaymentMethods.failed","Failed to get PaymentMethods from mercadolibre api",HttpStatus.SC_INTERNAL_SERVER_ERROR);
            }
        }
    }



}
