package ar.edu.unlam.connector.ecom.utils;

import org.apache.commons.io.IOUtils;
import java.util.zip.GZIPInputStream;
import java.util.Base64;
import java.io.ByteArrayInputStream;

public enum GZipUtils {

    INSTANCE;


    public String uncompressString(String zippedBase64Str)
        throws java.io.IOException {        
            String result;
            byte[] bytes = Base64.getDecoder().decode(zippedBase64Str);
            GZIPInputStream zip = null;

            try{
                zip = new GZIPInputStream(new ByteArrayInputStream(bytes));
                result = IOUtils.toString(zip);
            }finally{
                IOUtils.closeQuietly(zip);
            }

            return result;
    }
}
