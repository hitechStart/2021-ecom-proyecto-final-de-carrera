package ar.edu.unlam.connector.ecom.constants;

public enum ExecutionStatus {
    PENDING,RUNNING,COMPLETED,ERROR
}
