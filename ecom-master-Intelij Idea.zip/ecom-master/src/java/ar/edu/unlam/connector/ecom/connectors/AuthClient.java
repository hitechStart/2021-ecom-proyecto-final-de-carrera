package ar.edu.unlam.connector.ecom.connectors;

import ar.edu.unlam.connector.ecom.exceptions.ApiException;
import ar.edu.unlam.connector.ecom.utils.JsonUtils;
import org.apache.http.HttpStatus;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import java.util.HashMap;
import java.util.Map;

public enum AuthClient {

    INSTANCE;

    CloseableHttpClient httpClient = HttpClients.createDefault();

    public Map<String,Object> getAccessToken (String clientId, String clientSecret) throws Exception{
        HttpUriRequest request = new HttpPost("https://api.mercadolibre.com/oauth/token");
        request.setHeader("Content-Type", "application/json");

        Map<String,Object> params = new HashMap<>();
        params.put("grant_type","client_credentials");
        params.put("client_id",clientId);
        params.put("client_secret",clientSecret);

        StringEntity entity = new StringEntity(JsonUtils.INSTANCE.toString(params));
        ((HttpPost) request).setEntity(entity);
        CloseableHttpResponse response = null;
        try{
            response = httpClient.execute(request);
            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK || response.getStatusLine().getStatusCode() == HttpStatus.SC_CREATED){
                String result = EntityUtils.toString(response.getEntity());
                return JsonUtils.INSTANCE.toMap(result);
            }
            else
                throw new ApiException("get.at.failed",String.format("Failed to get access token from mercadolibre api"),HttpStatus.SC_INTERNAL_SERVER_ERROR);
        }
        catch(Exception e){
            throw new ApiException("get.at.failed",String.format("Failed to get access token from mercadolibre api"),HttpStatus.SC_INTERNAL_SERVER_ERROR);
        }
        finally {
            try {
                if (response != null)
                    response.close();
            }
            catch(Exception e){
                throw new ApiException("get.at.failed",String.format("Failed to get access token from mercadolibre api"),HttpStatus.SC_INTERNAL_SERVER_ERROR);
            }
        }
    }
}
