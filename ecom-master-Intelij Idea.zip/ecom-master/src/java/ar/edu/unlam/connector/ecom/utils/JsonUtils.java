package ar.edu.unlam.connector.ecom.utils;

import ar.edu.unlam.connector.ecom.exceptions.ApiException;
import com.fasterxml.jackson.databind.ObjectMapper;
import groovy.json.JsonException;
import org.apache.http.HttpStatus;

import java.util.List;
import java.util.Map;

public enum JsonUtils {

    INSTANCE;

    ObjectMapper mapper = new ObjectMapper();

    public Map toMap(String json){
        try {
            return mapper.readValue(json, Map.class);
        }
        catch(Exception e){
            throw new ApiException("json.parse.error","Failed to convert json to map",HttpStatus.SC_INTERNAL_SERVER_ERROR);
        }

    }

    public String toString(Map json){
        try {
            return mapper.writeValueAsString(json);
        }
        catch(Exception e){
            throw new ApiException("json.parse.error","Failed to convert json String",HttpStatus.SC_INTERNAL_SERVER_ERROR);
        }

    }

    public List toList(String json){
        try {
            return mapper.readValue(json, List.class);
        }
        catch(Exception e){
            throw new ApiException("json.parse.error","Failed to convert json to map",HttpStatus.SC_INTERNAL_SERVER_ERROR);
        }

    }

}
