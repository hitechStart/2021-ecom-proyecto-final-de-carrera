package ar.edu.unlam.connector.ecom.connectors;

import ar.edu.unlam.connector.ecom.exceptions.ApiException;
import ar.edu.unlam.connector.ecom.utils.JsonUtils;
import org.apache.http.HttpStatus;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import java.util.List;
import java.util.Map;

public enum LocationClient {

    INSTANCE;

    CloseableHttpClient httpClient = HttpClients.createDefault();

    /*traigo todos los paises*/
    public List getCountries (){
        HttpUriRequest request = new HttpGet("https://api.mercadolibre.com/countries");
        request.setHeader("Content-Type", "application/json");
        CloseableHttpResponse response = null;
        try{
            response = httpClient.execute(request);
            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK){
                String result = EntityUtils.toString(response.getEntity());
                return JsonUtils.INSTANCE.toList(result);
            }
            else{
                throw new ApiException("get.countries.failed","Failed to get countries from mercadolibre api",HttpStatus.SC_INTERNAL_SERVER_ERROR);
            }
        }
        catch(Exception e){
            throw new ApiException("get.countries.failed","Failed to get countries from mercadolibre api",HttpStatus.SC_INTERNAL_SERVER_ERROR);
        }
        finally {
            try {
                if (response != null)
                    response.close();
            }
            catch(Exception e){
                throw new ApiException("get.countries.failed","Failed to get countries from mercadolibre api",HttpStatus.SC_INTERNAL_SERVER_ERROR);
            }
        }
    }

    /*traigo datos paises por id*/
    public Map<String,Object> getCountriesById (String idCountry){
        HttpUriRequest request = new HttpGet(String.format("https://api.mercadolibre.com/countries/%s",idCountry));
        request.setHeader("Content-Type", "application/json");
        CloseableHttpResponse response = null;
        try{
            response = httpClient.execute(request);
            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK){
                String result = EntityUtils.toString(response.getEntity());
                /*return JsonUtils.INSTANCE.toList(result);*/
                return JsonUtils.INSTANCE.toMap(result);

            }
            else{
                throw new ApiException("get.getCountriesById.failed","Failed to get getCountriesById from mercadolibre api",HttpStatus.SC_INTERNAL_SERVER_ERROR);
            }
        }
        catch(Exception e){
            throw new ApiException("get.getCountriesById.failed","Failed to get getCountriesById from mercadolibre api",HttpStatus.SC_INTERNAL_SERVER_ERROR);
        }
        finally {
            try {
                if (response != null)
                    response.close();
            }
            catch(Exception e){
                throw new ApiException("get.getCountriesById.failed","Failed to get getCountriesById from mercadolibre api",HttpStatus.SC_INTERNAL_SERVER_ERROR);
            }
        }
    }

    /*traigo datos states por id*/
    public Map<String,Object> getStatesById (String idStates){
        HttpUriRequest request = new HttpGet(String.format("https://api.mercadolibre.com/states/%s",idStates));
        request.setHeader("Content-Type", "application/json");
        CloseableHttpResponse response = null;
        try{
            response = httpClient.execute(request);
            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK){
                String result = EntityUtils.toString(response.getEntity());
                /*return JsonUtils.INSTANCE.toList(result);*/
                return JsonUtils.INSTANCE.toMap(result);
            }
            else{
                throw new ApiException("get.getStatesById.failed","Failed to get getStatesById from mercadolibre api",HttpStatus.SC_INTERNAL_SERVER_ERROR);
            }
        }
        catch(Exception e){
            throw new ApiException("get.getStatesById.failed","Failed to get getStatesById from mercadolibre api",HttpStatus.SC_INTERNAL_SERVER_ERROR);
        }
        finally {
            try {
                if (response != null)
                    response.close();
            }
            catch(Exception e){
                throw new ApiException("get.getStatesById.failed","Failed to get getStatesById from mercadolibre api",HttpStatus.SC_INTERNAL_SERVER_ERROR);
            }
        }
    }

    /*traigo estados de argentina segun api argentina*/
    public Map<String,Object> getStatesArgentinaOfGobAr (){
        HttpUriRequest request = new HttpGet(String.format("https://apis.datos.gob.ar/georef/api/provincias?campos=completo"));
        request.setHeader("Content-Type", "application/json");
        CloseableHttpResponse response = null;
        try{
            response = httpClient.execute(request);
            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK){
                String result = EntityUtils.toString(response.getEntity());
                /*return JsonUtils.INSTANCE.toList(result);*/
                return JsonUtils.INSTANCE.toMap(result);
            }
            else{
                throw new ApiException("get.getStatesArgentinaOfGobAr.failed","Failed to get getStatesArgentinaOfGobAr from gob.ar api",HttpStatus.SC_INTERNAL_SERVER_ERROR);
            }
        }
        catch(Exception e){
            throw new ApiException("get.getStatesArgentinaOfGobAr.failed","Failed to get getStatesArgentinaOfGobAr from mercadolibre api",HttpStatus.SC_INTERNAL_SERVER_ERROR);
        }
        finally {
            try {
                if (response != null)
                    response.close();
            }
            catch(Exception e){
                throw new ApiException("get.getStatesArgentinaOfGobAr.failed","Failed to get getStatesArgentinaOfGobAr from mercadolibre api",HttpStatus.SC_INTERNAL_SERVER_ERROR);
            }
        }
    }

    /*traigo datos cities por id*/
    public Map<String,Object> getCitiesById (String idCities){
        HttpUriRequest request = new HttpGet(String.format("https://api.mercadolibre.com/cities/%s",idCities));
        request.setHeader("Content-Type", "application/json");
        CloseableHttpResponse response = null;
        try{
            response = httpClient.execute(request);
            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK){
                String result = EntityUtils.toString(response.getEntity());
                /*return JsonUtils.INSTANCE.toList(result);*/
                return JsonUtils.INSTANCE.toMap(result);
            }
            else{
                throw new ApiException("get.getCitiesById.failed","Failed to get getCitiesById from mercadolibre api",HttpStatus.SC_INTERNAL_SERVER_ERROR);
            }
        }
        catch(Exception e){
            throw new ApiException("get.getCitiesById.failed","Failed to get getCitiesById from mercadolibre api",HttpStatus.SC_INTERNAL_SERVER_ERROR);
        }
        finally {
            try {
                if (response != null)
                    response.close();
            }
            catch(Exception e){
                throw new ApiException("get.getCitiesById.failed","Failed to get getCitiesById from mercadolibre api",HttpStatus.SC_INTERNAL_SERVER_ERROR);
            }
        }
    }

    public Map<String,Object> getCitiesArgentinaOfGobAr (String idGob){
        HttpUriRequest request = new HttpGet(String.format("https://apis.datos.gob.ar/georef/api/localidades?provincia=%s&aplanar=true&campos=estandar&max=5000",idGob));
        request.setHeader("Content-Type", "application/json");
        CloseableHttpResponse response = null;
        try{
            response = httpClient.execute(request);
            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK){
                String result = EntityUtils.toString(response.getEntity());
                /*return JsonUtils.INSTANCE.toList(result);*/
                return JsonUtils.INSTANCE.toMap(result);
            }
            else{
                throw new ApiException("get.getCitiesById.failed","Failed to get getCitiesById from mercadolibre api",HttpStatus.SC_INTERNAL_SERVER_ERROR);
            }
        }
        catch(Exception e){
            throw new ApiException("get.getCitiesById.failed","Failed to get getCitiesById from mercadolibre api",HttpStatus.SC_INTERNAL_SERVER_ERROR);
        }
        finally {
            try {
                if (response != null)
                    response.close();
            }
            catch(Exception e){
                throw new ApiException("get.getCitiesById.failed","Failed to get getCitiesById from mercadolibre api",HttpStatus.SC_INTERNAL_SERVER_ERROR);
            }
        }
    }



}
