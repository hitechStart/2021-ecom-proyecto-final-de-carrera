package ar.edu.unlam.connector.ecom.configurations;

public enum Configurations {
    SEARCH_OFFSET_SIZE(50);

    private Integer value;

    // getter method
    public Integer getValue()
    {
        return this.value;
    }

    // enum constructor - cannot be public or protected
    private Configurations(Integer value)
    {
        this.value = value;
    }
}
