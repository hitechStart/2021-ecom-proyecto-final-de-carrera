package ar.edu.unlam.connector.ecom.constants;

public enum SearchType {
    LISTING,CATEGORY
}
