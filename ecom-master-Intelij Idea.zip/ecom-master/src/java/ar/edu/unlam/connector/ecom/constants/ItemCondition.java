package ar.edu.unlam.connector.ecom.constants;

public enum ItemCondition {
    NUEVO("Nuevo"),
    USADO("Usado"),
    AMBOS("No Especifica");

    private final String stringValue;

   // enum constructor - cannot be public or protected
    ItemCondition(final String value)
    {
        stringValue = value;
    }

    // getter method
    public String getValue()
    {
        return stringValue;
    }
}
