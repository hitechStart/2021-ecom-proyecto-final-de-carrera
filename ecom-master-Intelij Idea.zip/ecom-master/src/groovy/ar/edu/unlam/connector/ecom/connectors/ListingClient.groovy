package ar.edu.unlam.connector.ecom.connectors

import ar.edu.unlam.connector.ecom.configurations.Configurations;
import ar.edu.unlam.connector.ecom.constants.OperationProcessType;
import ar.edu.unlam.connector.ecom.exceptions.ApiException;
import ar.edu.unlam.connector.ecom.utils.JsonUtils;
import ecom.Auth;
import ecom.Criteria;
import ecom.CriteriaAttributes;
import ecom.db.OperationLogsService;
import org.apache.http.HttpStatus;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import java.nio.charset.StandardCharsets;

enum ListingClient {

    INSTANCE;

    def operationLogService

    CloseableHttpClient httpClient = HttpClients.createDefault();

    public Map<String,Object> getItemById (String itemId){
        HttpUriRequest request = new HttpGet(String.format("https://api.mercadolibre.com/items/%s",itemId));
        request.setHeader("Content-Type", "application/json");
        CloseableHttpResponse response = null;
        try{
            response = httpClient.execute(request);
            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK){
                String result = EntityUtils.toString(response.getEntity());
                return JsonUtils.INSTANCE.toMap(result);
            }
            else
                throw new ApiException("get.item.by.id.failed",String.format("Failed to get item %s from mercadolibre api",itemId),HttpStatus.SC_INTERNAL_SERVER_ERROR);
        }
        catch(Exception e){
            throw new ApiException("get.item.by.id.failed",String.format("Failed to get item %s from mercadolibre api",itemId),HttpStatus.SC_INTERNAL_SERVER_ERROR);
        }
        finally {
            try {
                if (response != null)
                    response.close();
            }
            catch(Exception e){
                throw new ApiException("get.item.by.id.failed",String.format("Failed to get item %s from mercadolibre api",itemId),HttpStatus.SC_INTERNAL_SERVER_ERROR);
            }
        }
    }


    Map<String,Object> searchListingByCategoryAndQuery (Criteria criteria, int offset, Configurations limit, Auth auth)throws UnsupportedEncodingException {
        String idCategory = criteria.category.idCategoryML;
        String query = criteria.searchCriteria;
        Set<CriteriaAttributes> attributes = criteria.criteriaAttributes;
        String uri,parameters = "";

        if (idCategory != null && idCategory != "")
            parameters+= String.format("category=%s&",idCategory);

        if (query != null && query != "")
            parameters+= String.format("q=%s&",URLEncoder.encode(query, StandardCharsets.UTF_8.toString()));

        attributes.each { attribute ->
            parameters+= String.format("%s=%s&",attribute.idAttributeML,attribute.idAttributeValueML)
        }

        parameters +=String.format("offset=%d&limit=%d",offset,limit.getValue());
        uri = String.format("https://api.mercadolibre.com/sites/MLA/search?%s",parameters);
        return executeListingSearch(uri,auth);
    }

    private Map<String,Object> executeListingSearch(String uri, Auth auth) {
        HttpUriRequest request = new HttpGet(uri);
        request.setHeader("Content-Type", "application/json");
        request.setHeader("Authorization",String.format("Bearer %s",auth.getAccessToken()));
        CloseableHttpResponse response = null;
        Map result = null;
        int retries = 4;
        boolean success = false;
        try {
            while (!success && retries > 0){
                try{
                    response = httpClient.execute(request);
                    if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK){
                        result = JsonUtils.INSTANCE.toMap(EntityUtils.toString(response.getEntity()));
                        success = true;
                        operationLogService.saveSuccess(uri, OperationProcessType.IMPORT_LISTING_BY_CATEGORY,response.getStatusLine().toString(), (long) ((List)result.get("results")).size());
                    }
                    else if (response.getStatusLine().getStatusCode() == HttpStatus.SC_UNAUTHORIZED || response.getStatusLine().getStatusCode() == HttpStatus.SC_FORBIDDEN )
                        throw new ApiException("executeListingSearch.failed","Failed to get ListingByCategoryAndQuery from mercadolibre api",HttpStatus.SC_INTERNAL_SERVER_ERROR);
                    else{
                        retries --
                        Thread.sleep(100)
                        operationLogService.saveError(uri,OperationProcessType.IMPORT_LISTING_BY_CATEGORY,response.getStatusLine().toString());
                    }
                }
                catch(Exception e){
                    retries --;
                    operationLogService.saveException(uri,OperationProcessType.IMPORT_LISTING_BY_CATEGORY,e.getMessage());
                    try {
                        Thread.sleep(100)
                    }
                    catch(InterruptedException ex){
                    }
                }
            }
            if (!success)
                throw new ApiException("executeListingSearch.failed","Failed to get ListingByCategoryAndQuery from mercadolibre api",HttpStatus.SC_INTERNAL_SERVER_ERROR);
            else
                return result;
        }
        finally {
            try {
                if (response != null)
                    response.close();
            }
            catch(Exception e){
                throw new ApiException("executeListingSearch.failed","Failed to get ListingByCategoryAndQuery from mercadolibre api",HttpStatus.SC_INTERNAL_SERVER_ERROR);
            }
        }


    }

}
