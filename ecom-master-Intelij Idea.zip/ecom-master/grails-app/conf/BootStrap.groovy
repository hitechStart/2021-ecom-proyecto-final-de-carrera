
import ecom.Auth
import ecom.ListingService


class BootStrap {

    def accessTokenService
    def wordService

    def init = { servletContext ->
       createToken()
    }

    def destroy = {
    }

    void createToken(){
        if (Auth.list().size() == 0)
            accessTokenService.getAccessToken(true)
    }

}
