package ecom

class BackFilters {

    def filters = {
        all(controller:'*', action:'*') {
            before = {

            }
            after = { Map model ->
                String requestURI = request.forwardURI
                StringBuilder requestURL = new StringBuilder(request.getRequestURL().toString());
                String queryString = request.getQueryString();
                def url = null
                if (queryString == null) {
                    url = requestURI;
                } else {
                    url = requestURI + '?' + queryString;
                }
                if(session.controller == null)
                    session.controller = ""
                if(session.action == null)
                    session.action = ""
                if(session.backUrl== null) {
                    session.backUrl = url
                    session.backHref = session.backUrl
                }

                if((session.controller != controllerName && controllerName != null) || (session.action != actionName && actionName != null))
                {
                    session.backHref  = session.backUrl
                    session.backUrl = url
                    session.controller = controllerName
                    session.action = actionName
                }  else {
                    session.backUrl = url
                }
                return true
            }
            afterView = { Exception e ->

            }
        }
    }
}
