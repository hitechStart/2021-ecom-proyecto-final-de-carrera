package ecom

class ItemGrouping {
    Integer id
    Long version
    String groupingType
    Integer idGrouping
    String nameML
    String groupDescription


    static constraints = {
        groupingType(unique: ['idGrouping'])
    }

    static mapping = {
        table 'ItemGrouping'
        id column: 'id'
        version column: 'version'
        groupingType column: 'GroupingType'
        idGrouping column: 'IdGrouping'
        nameML column: 'Nameml'
        groupDescription column: 'GroupDescription'
    }
}


