package ecom

class Auth {

    String clientId
    String clientSecret
    String accessToken
    String tokenType
    Date dateCreated
    Date lastUpdated


    static constraints = {
    }
}
