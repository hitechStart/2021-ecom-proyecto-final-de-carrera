package ecom

class TrendsCountry {

    Long idTrendsCountry
    String trends
    Date fechaEjecucion
    Boolean estado
    String linkML
    Long cantidadPublicaciones

    static mapping = {

        id name:'idTrendsCountry'
    }

    static constraints = {
        /*sirve para que permita nulos en la base*/
        trends nullable: true
        fechaEjecucion nullable: true
        estado nullable:true
        linkML nullable:true
        cantidadPublicaciones nullable:true
    }

    TrendsCountry()
    {}

    TrendsCountry(String trends, Date fechaEjecucion, Boolean estado, String linkML, Long cantidadPublicaciones)
    {
        this.trends=trends
        this.fechaEjecucion=fechaEjecucion
        this.estado= estado
        this.linkML=linkML
        this.cantidadPublicaciones=cantidadPublicaciones
    }
}
