package ecom


class ListingWords implements Serializable {

    String word

    static mapping = {

    }
    static constraints = {

    }

    static belongsTo = [listing: Listing]

}
