package ecom

class PaymentMethods {
    Long idPaymentMethod
    String idML
    String name
    String payment_type_id

    static mapping = {
        /*define que el id sea autoincremental*/
        id name: 'idPaymentMethod'
    }


    static constraints = {

        /*sirve para que permita nulos en la base*/
        idML nullable: true
        name nullable: true
        payment_type_id nullable:true

    }


    PaymentMethods (String idML, String name, String payment_type_id)
    { this.idML=idML
    this.name=name
    this.payment_type_id=payment_type_id
    }

    PaymentMethods()
    {}

}
