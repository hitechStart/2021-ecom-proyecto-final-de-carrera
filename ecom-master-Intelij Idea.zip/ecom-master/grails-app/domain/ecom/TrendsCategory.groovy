package ecom

class TrendsCategory {

    Long idTrendsCategory
    Integer trendPosition
    String idCategoryML
    String trends
    Date fechaEjecucion
    Boolean estado
    String linkML
    Long cantidadPublicaciones
    Long cantidadVentas
    Double ventasPorPublicacion

    static belongsTo = [execution:Executions]
    static mapping = {

        id name:'idTrendsCategory'
    }

    static constraints = {
        /*sirve para que permita nulos en la base*/
        trends nullable: true
        fechaEjecucion nullable: true
        estado nullable:true
        idCategoryML nullable:true
        linkML nullable:true
        cantidadPublicaciones nullable:true
        ventasPorPublicacion nullable:true
        cantidadVentas nullable:true
    }

    TrendsCategory()
    {}

    TrendsCategory(String trends, Date fechaEjecucion, Boolean estado, String idCategoryML, String linkML, Long cantidadPublicaciones, Executions ejecucion, Integer trendPos, Long cantidadVentas, Double ventasPorPublicacion)
    {
        this.trends=trends
        this.fechaEjecucion=fechaEjecucion
        this.estado= estado
        this.idCategoryML=idCategoryML
        this.linkML=linkML
        this.cantidadPublicaciones=cantidadPublicaciones
        this.execution = ejecucion
        this.trendPosition = trendPos
        this.cantidadVentas= cantidadVentas
        this.ventasPorPublicacion=ventasPorPublicacion
    }
}
