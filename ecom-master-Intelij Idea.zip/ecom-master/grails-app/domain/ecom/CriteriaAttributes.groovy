package ecom

class CriteriaAttributes {

    Long idCriteriaAttribute
    String idAttributeML
    String nameAttributeML
    String idAttributeValueML
    String nameAttributeValueML

    static mapping = {
        id name: 'idCriteriaAttribute'
    }

    static constraints = {
        //relatedLink(nullable: true)
    }

    static belongsTo = [criteria:Criteria]
}
