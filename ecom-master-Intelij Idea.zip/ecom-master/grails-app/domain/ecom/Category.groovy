package ecom

class Category {

    String idCategoryPadre
    Integer level
    String  idCategoryML
    String nameML
    String pictureML
    String linkML
    Integer total_itemsML
    String fechaUltimaActualizacion

    static mapping = {
        id name: 'idCategoryML', generator: 'assigned'
    }

    static hasMany = [attributes: CategoryAttributes]

    static constraints = {
            idCategoryPadre nullable:true
            idCategoryML nullable: false, blank: false
            level nullable: false
            nameML nullable: false , blank:false
            pictureML nullable: true
            linkML nullable: true
            total_itemsML nullable: true
    }

    Category(){}

    Category(String idCategoryPadre, String idCategoryML, String nameMl, Integer total_itemsML, Integer level, String fecha, String picture, String link){
        this.idCategoryPadre = idCategoryPadre
        this.idCategoryML = idCategoryML
        this.nameML = nameMl
        this.total_itemsML = total_itemsML
        this.level = level
        this.fechaUltimaActualizacion = fecha;
        this.pictureML=picture
        this.linkML=link
    }


}
