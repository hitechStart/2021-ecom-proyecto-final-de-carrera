package ecom

class CategoryAttributes {

    Long idCategoryAttribute

    String idAttributeML
    String nameML
    String value_typeML
    String attribute_group_idML
    String attribute_group_nameML

    static mapping = {
        id name: 'idCategoryAttribute'
    }
    static hasMany = [attributeValues: CategoryAttributeValues]
    static belongsTo = [category: Category]

    static constraints = {
        idAttributeML nullable: true
        nameML nullable: true
        value_typeML nullable: true
        attribute_group_idML nullable: true
        attribute_group_nameML nullable: true
    }

    CategoryAttributes()
    {}

    CategoryAttributes(Category category,String idAttributeML,String nameML,String value_typeML,String attribute_group_idML,String attribute_group_nameML)
    {
        this.category=category
        this.nameML=nameML
        this.value_typeML=value_typeML
        this.attribute_group_idML=attribute_group_idML
        this.attribute_group_nameML=attribute_group_nameML
        this.idAttributeML=idAttributeML
    }
}
