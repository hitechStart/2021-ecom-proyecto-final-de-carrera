package ecom

class Address {

    String stateId
    String stateName
    String cityId
    String cityName

    static constraints = {
        stateName(nullable: true)
        stateId(nullable: true)
        cityId(nullable: true)
        cityName(nullable: true)
    }

    static belongsTo = [listing:Listing]
}
