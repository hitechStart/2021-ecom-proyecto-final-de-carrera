package ecom

class CategoryAttributeValues {

    Long idCategoryAttributeValue
    String idValueML
    String nameML


    static mapping = {
        id name: 'idCategoryAttributeValue'
    }
    static belongsTo = [categoryAttribute: CategoryAttributes]
    static constraints = {
    }

    CategoryAttributeValues (CategoryAttributes idCategoryAttributes, String idValueMl, String nameML) {
        this.idValueML=idValueMl
        this.nameML=nameML
        this.categoryAttribute=idCategoryAttributes
    }

    CategoryAttributeValues()
    {}


}
