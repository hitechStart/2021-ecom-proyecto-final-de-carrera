package ecom

class Events {
    Long idEvent
    String name
    Date fechaDesde
    Date fechaHasta
    Boolean estado


    static mapping = {

        id name:'idEvent'
    }



    static constraints = {

        /*sirve para que permita nulos en la base*/
        name nullable: true
        fechaDesde nullable: true
        fechaHasta nullable:true
        estado nullable:true

    }


    Events()
    {}

    Events(String name, Date fechaDesde, Date fechaHasta,Boolean estado)
    {
        this.name=name
        this.fechaDesde=fechaDesde
        this.fechaHasta=fechaHasta
        this.estado=estado
    }
}
