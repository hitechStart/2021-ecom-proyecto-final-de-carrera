package ecom

class Installment {

    Long quantity
    Double amount
    Double rate
    String currencyId

    static constraints = {
    }

    static belongsTo = [listing:Listing]
}
