package ecom

class Users {

    String idUser
    String name

    static mapping = {
        id name: 'idUser', generator: 'assigned'
    }

    static constraints = {
    }

    static hasMany = [searches: Searches]
}
