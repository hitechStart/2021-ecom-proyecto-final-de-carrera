package ecom

class Listing implements Serializable{

    String idMl
    String siteId
    String title
    Double price
    String currencyId
    Long availableQuantity
    Long soldQuantity
    Double originalPrice
    Long officialStoreId
    String catalogProductId
    Boolean acceptsMercadopago
    String buyingMode
    String listingTypeId
    String permalink

    Long orderBackend
    String thumbnail
    String thumbnailId
    String tags
    Boolean useThumbnailId
    String domainId
    Date stopTime
    String listingCondition
    Date dateCreated
    Long totalQuestions
    Long visitsQuantity
    Long reviewsQuantity
    Double ratingAverage
    Boolean elegible

    static belongsTo = [criteria:Criteria,execution:Executions,category:Category,seller:Seller]
    static hasOne = [installment:Installment,shipping:Shipping,address: Address]
    static hasMany = [orders:PurchaseOrder]

    static mapping = {
        id composite:["idMl","execution"]
        sort soldQuantity: "desc"
    }

    static constraints = {

        siteId(nullable: true)
        elegible(elegible: true)
        title(nullable: true)
        price(nullable: true)
        currencyId(nullable: true)
        availableQuantity(nullable: true)
        soldQuantity(nullable: true)
        originalPrice(nullable:true)
        officialStoreId(nullable:true)
        catalogProductId(nullable:true)
        acceptsMercadopago(nullable: true)
        buyingMode(nullable: true)
        listingTypeId(nullable: true)
        permalink(nullable: true)
        thumbnail(nullable:true)
        thumbnailId(nullable: true)
        stopTime(nullable: true)
        orderBackend(nullable: true)
        useThumbnailId(nullable: true)
        domainId(nullable: true)
        listingCondition(nullable: true)
        criteria(nullable: true)
        execution(nullable:true)
        totalQuestions(nullable:true)
        visitsQuantity(nullable:true)
        reviewsQuantity(nullable:true)
        ratingAverage(nullable:true)
    }



}
