package ecom

class ShippingModes {

    Long idShippingMode
    String symbolML
    String name
    String description

    static mapping = {
        id name: 'idShippingMode'
    }
    static constraints = {
    }
}
