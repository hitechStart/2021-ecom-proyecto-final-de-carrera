package ecom

class Country {

    String idCountry
    String name
    String currency
    Double latitud
    Double longitud

    static mapping = {
        id name: 'idCountry' , generator: 'assigned'

    }

    static hasMany = [states: State]

    static constraints = {
        /*sirve para que permita nulos en la base*/

        name nullable: true
        currency nullable: true
        latitud nullable:true
        longitud nullable:true

    }

    Country(){}

    Country (String id,String name, String currency, Double latitud, Double longitud)
    {
        this.idCountry=id
        this.name=name
        this.currency=currency
        this.latitud=latitud
        this.longitud=longitud
    }
}
