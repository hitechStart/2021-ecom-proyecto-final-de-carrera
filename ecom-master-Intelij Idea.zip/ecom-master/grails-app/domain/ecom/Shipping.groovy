package ecom

class Shipping {

    Boolean freeShipping
    String mode
    String tags
    String logisticType
    Boolean storePickUp

    static constraints = {
    }

    static belongsTo = [listing:Listing]
}
