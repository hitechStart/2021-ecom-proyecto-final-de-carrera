package ecom

import ar.edu.unlam.connector.ecom.constants.ExecutionStatus

class Executions {

    Long idExecution
    ExecutionStatus executionStatus
    Date dateCreated
    Date dateExecuted
    Date dateFinished
    Long listingQtty
    String errorDescription

    static mapping = {
        id name: 'idExecution'
    }

    static constraints = {
        dateExecuted(nullable: true)
        dateFinished(nullable: true)
        errorDescription(nullable: true)
    }

    static belongsTo = [search:Searches]
    static hasMany = [listings:Listing]
}
