package ecom

import ar.edu.unlam.connector.ecom.constants.SearchType


class Searches {

    Long idSearch
    String name
    String description
    SearchType searchType
    String catalog_product_idML
    String listingPermalink
    int status

    static mapping = {
        id name: 'idSearch'
        status defaultValue: 1
    }

    static constraints = {
        catalog_product_idML(nullable: true)
        listingPermalink(nullable: true)
    }

    static belongsTo = [user: Users]
    static hasMany = [criteria:Criteria,executions:Executions]
}
