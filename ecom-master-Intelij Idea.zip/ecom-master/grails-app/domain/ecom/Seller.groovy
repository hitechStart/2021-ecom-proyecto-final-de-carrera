package ecom

class Seller implements Serializable{

    Long idMl
    String permalink
    Date registrationDate
    Boolean carDealer
    Boolean realStateAgency
    String tags
    String sellerType


    static hasMany = [listings:Listing]
    static belongsTo = [execution:Executions]

    static mapping = {
        id composite:["idMl","execution"]
    }

    static constraints = {
        registrationDate(nullable: true)
        permalink(nullable: true)
        tags(nullable: true)
    }

}
