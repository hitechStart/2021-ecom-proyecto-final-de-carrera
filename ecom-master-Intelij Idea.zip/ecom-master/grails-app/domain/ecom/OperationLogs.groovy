package ecom

import ar.edu.unlam.connector.ecom.constants.OperationProcessType

class OperationLogs {
    Long id
    OperationProcessType operationType
    Date operationDate
    String source
    String description
    String result
    Long resultQty
    String errorDescription

    static constraints = {
        errorDescription(nullable: true)
        resultQty(nullable: true)
        description(nullable: true)
        resultQty(nullable: true)
        result(nullable: true)
    }
}
