package ecom

class Criteria {

    Long idCriteria
    String searchCriteria
    String relatedLink
    Long quantity
    String itemCondition

    static mapping = {
        id name: 'idCriteria'
    }

    static constraints = {
        relatedLink(nullable: true)
        quantity(nullable: true)
        itemCondition(nullable: true)
    }

    static belongsTo = [search:Searches,category: Category]
    static hasMany = [listings:Listing, criteriaAttributes: CriteriaAttributes]

    String getAttrsString(){
        String finalAttrs = ""
        criteriaAttributes.each {
            finalAttrs = finalAttrs + it.nameAttributeML + ":" + it.nameAttributeValueML + "<BR/>"
        }
        return finalAttrs
    }

}
