package ecom

class State {

    String idState
    String name
    Double latitud
    Double longitud
    String idGob

    static mapping = {
        id name: 'idState' , generator: 'assigned'
    }

    static hasMany = [cities: City]
    static belongsTo = [country: Country]

    static constraints = {


        name nullable: true
        latitud nullable:true
        longitud nullable:true
        idState nullable:true
        country nullable:true
        idGob nullable:true
    }

    State(){}

    State(Country country,String idState, String name, Double latitud, Double longitud,String idGob)
        {
            this.idState=idState
            this.name=name
            this.latitud=latitud
            this.longitud=longitud
            this.country=country
            this.idGob=idGob
        }
}
