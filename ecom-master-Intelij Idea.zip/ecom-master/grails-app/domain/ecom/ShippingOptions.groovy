package ecom

class ShippingOptions {

    Long idShippingOption
    String symbolML
    String name
    String description

    static mapping = {
        id name: 'idShippingOption'
    }
    static constraints = {
    }
}
