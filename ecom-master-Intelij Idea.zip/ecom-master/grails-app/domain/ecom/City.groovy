package ecom

class City implements Serializable {

    String idCity
    String name
    Double latitud
    Double longitud
    String idCityGob

    static mapping = {

        id name: 'idCity' , generator: 'assigned'
    }
    static belongsTo = [state: State]
    static constraints = {


        name nullable: true
        latitud nullable:true
        longitud nullable:true
        idCity nullable: true
        idCityGob nullable: true
        state nullable: true
    }

    City(){}

    City(State state,String idCity, String name, Double latitud, Double longitud,String idCityGob)
    {
        this.idCity=idCity
        this.name=name
        this.latitud=latitud
        this.longitud=longitud
        this.state=state
        this.idCityGob= idCityGob
    }
}
