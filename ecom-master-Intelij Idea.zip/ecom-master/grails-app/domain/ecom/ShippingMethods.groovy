package ecom

class ShippingMethods {
Long idShippingMethods
String name
String status
String site_id
String free_options
String shipping_modes
Integer company_id
String company_name
    static mapping = {
        /*define que el id sea autoincremental*/
        id name: 'idShippingMethods'
    }

    static constraints = {
        /*sirve para que permita nulos en la base*/
        free_options nullable: true
        shipping_modes nullable: true
        company_id nullable:true
        company_name nullable:true
    }

    ShippingMethods ( String name, String status, String site_id, String free_options,String shipping_modes,Integer company_id, String company_name){

        this.name = name
        this.status = status
        this.site_id = site_id
        this.free_options = free_options
        this.shipping_modes = shipping_modes
        this.company_id = company_id
        this.company_name = company_name




}

    ShippingMethods()
    {}
}