package ecom

class PurchaseOrder implements Serializable{

    Boolean fulfilled
    String buyingMode
    Long quantity
    String listingTypeId
    Double unitPrice
    Double fullUnitPrice
    Date dateCreated
    String tags
    Long buyerId
    Double totalAmount
    Double paidAmount
    String status
    Double shippingCost
    String shippingMode
    String shippingStatus
    Long shippingServiceId
    String senderCountry
    String senderStateId
    String senderCityId
    String receiverCountry
    String receiverStateId
    String receiverCityId
    String logisticType
    Long shippingOptionId
    Long shippingMethodId
    String shippingOptionName
    Long orderId

    String senderCountryName
    String senderStateName
    String senderCityName
    String receiverCountryName
    String receiverStateName
    String receiverCityName


    static belongsTo = [listing:Listing]
    static mapping = {
        id name: 'orderId'
    }

    static constraints = {
        shippingCost(nullable: true)
        shippingMode(nullable: true)
        shippingStatus(nullable: true)
        shippingServiceId(nullable: true)
        senderCountry(nullable: true)
        senderStateId(nullable: true)
        senderCityId(nullable: true)
        receiverCountry(nullable: true)
        receiverStateId(nullable: true)
        receiverCityId(nullable: true)
        logisticType(nullable: true)
        shippingOptionId(nullable: true)
        shippingMethodId(nullable: true)
        shippingOptionName(nullable: true)

        senderCountryName(nullable: true)
        senderStateName(nullable: true)
        senderCityName(nullable: true)
        receiverCountryName(nullable: true)
        receiverStateName(nullable: true)
        receiverCityName(nullable: true)

    }
}
