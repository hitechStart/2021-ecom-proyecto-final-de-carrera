package ecom

class EventsController {
    def eventsService
    def list()
        {
            def eventos = eventsService.getEventsDB()

            [eventList : eventos]
        }



    def updateInsert()
    {
        Events evento = new Events()
        Boolean activado = false

        if(params.confirmar!=null)
        {
            if(params.idEvent!=null && params.idEvent!="")
            {

                if(params.estado)
                    {activado=true}
                eventsService.updateEvents(Long.parseLong(params.idEvent),params.nombre,params.fechaDesde,params.fechaHasta,activado)
            }
            else {
                if(params.estado)
                {activado=true}
                eventsService.saveEvents(params.nombre,params.fechaDesde,params.fechaHasta,activado)
            }
            redirect (action:'list')
        }
        else {
            if(params.id!=null)
            {
                evento = eventsService.getEventDBById(Long.parseLong(params.id))

            }
        }
        [evento : evento]

    }

    def delete()
    {
        eventsService.deleteEvents(Long.parseLong(params.id))


        redirect (action:'list')
    }
}
