package ecom

class ShippingController {
def shippingService



    def list() {

        def shippingList = shippingService.getShippingMethodsDB()

        [shippingMethods:shippingList]
    }

    def save() {
        def saveOK = shippingService.saveShippingMethods()
        if(saveOK) {
            [data:"Se guardo correctamente"]
        } else {
            [data:"Error al guardar"]
        }


    }



}
