package ecom

class LocationController {
/*Controller para guardar y recuperar country, state, city*/
    def countryService
    def stateService
    def cityService
    def listingDbService
    def listingService

    def saveAll() {
        def saveOK = countryService.saveCountry()
        if(saveOK) {
            saveOK = stateService.saveState()
            if(saveOK) {
                saveOK = cityService.saveCity()
                if(saveOK) {
                    [data:"Se guardo correctamente"]
                } else {
                    [data:"Error al guardar"]
                }
            } else {
                [data:"Error al guardar"]
            }
        } else {
            [data:"Error al guardar"]
        }
    }

    def saveOneForOne()
        {
            try {
                def saveOK = countryService.saveCountry()

                if(saveOK) {
                    for(Country pais : Country.findAll().toList())
                    {
                        if(pais.getAt("idCountry")=="AR")
                        {stateService.saveStatesGobAr()}
                        else
                        {stateService.saveStateByCountry(pais.getAt("idCountry"))}



                    }

                    for (State state : State.findAll().toList())
                    {
                        cityService.saveCityByState(state.getAt("idState"))
                    }

                } else {
                    [data:"Error al guardar"]
                }
        }
        catch (Exception e)
        {
            println (e.getMessage())
            data:"Error al cargar datos de locación"
        }


        }

    def saveCountry ()
    {
        def saveOK = countryService.saveCountry()
            if(saveOK) {
                [data:"Se guardo correctamente"]
            } else {
                [data:"Error al guardar"]
            }
    }

    def saveState()
    {
        def saveOK
        for(Country pais : Country.findAll().toList())
        {

            saveOK = stateService.saveStateByCountry(pais.getAt("idCountry"))


        }

        if(saveOK) {
            [data:"Se guardo correctamente"]
        } else {
            [data:"Error al guardar"]
        }
    }

    def saveStateGobAr()
    {
        def saveOK


            saveOK = stateService.saveStatesGobAr()




        if(saveOK) {
            [data:"Se guardo correctamente"]
        } else {
            [data:"Error al guardar"]
        }
    }

    def saveCity ()
    {   def saveOK

        for (State state : State.findAll().toList())
        {
             saveOK = cityService.saveCityByState(state.getAt("idState"))
        }
        if(saveOK) {
            [data:"Se guardo correctamente"]
        } else {
            [data:"Error al guardar"]
        }
    }

    def listCountry() {

        def countryList = countryService.getCountriesDB()

        [country : countryList]
    }

    def listState() {

        def stateList = stateService.getStateDB()

        [state :stateList]
    }

    def listCity() {

        def cityList = cityService.getCityDB()

        [city:cityList]
    }

    def saveArgentina()
    {try {
        def saveOK = countryService.saveArgentina()

        if(saveOK) {
            for(Country pais : Country.findAll().toList())
            {
                if(pais.getAt("idCountry")=="AR")
                {
                    stateService.saveStatesGobAr()
                }
                else {
                    stateService.saveStateByCountry(pais.getAt("idCountry"))

                }



            }

            for (State state : State.findAll().toList())
            {
                cityService.saveCityByState(state.getAt("idState"))


            }

            for (State state : State.findAll().toList())
            {
                if(state.getAt("idGob"))

                {
                    cityService.saveCityByGob(state.getAt("idState"),state.getAt("idGob"))
                }

            }

        } else {
            [data:"Error al guardar"]
        }
    }
    catch (Exception e)
    {
        println (e.getMessage())
        data:"Error al cargar datos de locación"
    }


    }


    def listingZone(def params) {
        List<State> data = stateService.getStateDBByCountry("AR")
        def listado = null
        def ejecucion = params.id

        if(ejecucion == null)
            ejecucion = params.ejecucion

        if(params.estado != null){
            State state = State.get(params.estado)
            listado = cityService.getCityDBByState(state)

        }

        render(view: "location",model:[data: data, state:params.estado, listing:listado,execution:ejecucion])
    }

    def listingZonePorPublicacion(def params) {
        //List<Address> data = listingService.getGroupsZone()
        def listado = null
        def total = 0;
        def ejecucion = params.id
        def max = 10
        if(params.max != null)
            max = Integer.parseInt(params.max)
        def offset = 0
        if(params.offset != null)
            offset = Integer.parseInt(params.offset)
        if(ejecucion == null)
            ejecucion = params.ejecucion
        if(params.idCity != null){
            listado = listingService.getListingPorZone(params.idCity, Long.parseLong(params.ejecucion), max, offset)
            total = listingService.getListingPorZoneTotal(params.idCity, Long.parseLong(params.ejecucion))
        }

        render(view: "listingZone",model:[city:params.idCity, ejecucion:ejecucion, listing:listado, total: total, nombreCiudad:params.nombre])
    }

    def deleteCity()
    {
        cityService.deleteCity(params.id)


        redirect (action:'location')
    }



    def updateInsertCity()
    {
        State estado = State.get(params.idState)
        City ciudad = new City()



        if(params.confirmar!=null)
        {
            if(params.idCity!=null && params.idCity!="")
            {


                cityService.updateCity(params.idCity,params.name,Double.parseDouble(params.latitud),Double.parseDouble(params.longitud))
            }
            else {

                cityService.insertCity(params.idState,params.name,Double.parseDouble(params.latitud),Double.parseDouble(params.longitud))
            }
            redirect (action:'location')
        }
        else {
            if(params.idCity!=null)
            {
                ciudad = cityService.getCityDBById(params.idCity)

            }
        }
        [ciudad : ciudad, estado:params.idState]

    }



}
