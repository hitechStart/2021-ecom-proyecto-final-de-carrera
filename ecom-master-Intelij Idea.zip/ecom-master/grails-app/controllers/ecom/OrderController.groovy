package ecom

class OrderController {

    def fileService

    def list(def params) {
        if (params.path)
            fileService.saveOrders(params.path,null)
    }
}
