package ecom

class CategoryAttributesController {
def categoryAttributesService
def categoriesService
    def search() {

        def categoryAttributesList = categoryAttributesService.getCategoryAttributesDB()

        [data:categoryAttributesList,display_l2:false]
    }

    def save() {
        def saveOK = true
        def categoriesList = categoriesService.getCategoriesDB()
        for(Category cat : categoriesList)
        {
             saveOK = categoryAttributesService.saveCategoryAttributes(cat)
            if(!saveOK)
                break
        }
        if(saveOK) {
            [data:"Se guardo correctamente"]
        } else {
            [data:"Error al guardar"]
        }


    }
}
