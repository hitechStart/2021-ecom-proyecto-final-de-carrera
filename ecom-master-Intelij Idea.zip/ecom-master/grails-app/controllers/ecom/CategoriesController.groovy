package ecom

import java.text.DateFormat
import java.text.SimpleDateFormat

class CategoriesController {

    def categoriesService

    def list() {
        List<Category> categoriesList = new ArrayList<Category>()
        String idPadre = ""
        def end = true
        def arbolSeleccionado = ""
        def visual = ""
        if (params.finalizar == null) {
                if (params.id == "0" || params.id == null || params.id == "") {
                    categoriesList = categoriesService.getCategoriesPadre()
                    visual = "none"
                } else {
                    categoriesList = categoriesService.getCategoriesHijas(params.id)
                    idPadre = categoriesService.getCategoryIdPadre(params.id)
                }
                if (categoriesList.size() > 0) {
                    end = false
                } else {
                    arbolSeleccionado = categoriesService.getArbolSeleccionado(params.id)
                }
         } else {
            arbolSeleccionado = categoriesService.getArbolSeleccionado(params.id)
            idPadre = categoriesService.getCategoryIdPadre(params.id)
        }
        [visual:visual,categoryList:categoriesList, display_end:end, padre: idPadre, arbol: arbolSeleccionado, actual:params.id]
    }

    def traerHijas() {
        def categoriesList = categoriesService.getCategoriesPadre()
        [categoryList:categoriesList]
    }

    def save() {
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
        Date date = new Date();
        String fecha = dateFormat.format(date);
        def saveOK = categoriesService.saveCategories(fecha)
        def categoriesList = categoriesService.getCategoriesDB()
        for(Category cat : categoriesList)
        {
            def detalles = categoriesService.getCategoryById(cat.idCategoryML)
            categoriesService.saveChilds(detalles,1, cat.idCategoryML,fecha)
        }
        if(saveOK) {
            [data:"Se guardo correctamente"]
        } else {
            [data:"Error al guardar"]
        }
    }

    def presave() {
        def total = categoriesService.getCategoriesTotal()
        def ultimaFecha = ""
        if(total > 0)
        {
            ultimaFecha = categoriesService.getFechaUltimaActualizacion()
        }
        [totalCargadas:total, fecha:ultimaFecha]
    }

    def update()
    {
        def resultado
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
        Date date = new Date();
        String fecha = dateFormat.format(date);
        def data
        for(Object cat : categoriesService.getCategoriesDB())
        {
            try {
                resultado = categoriesService.updateCategoriesById(cat.getAt("idCategoryML"),fecha)

                }
            catch(Exception e)
            {println (e.getMessage())}
        }
        [data:"Se guardo correctamente"]
    }


}
