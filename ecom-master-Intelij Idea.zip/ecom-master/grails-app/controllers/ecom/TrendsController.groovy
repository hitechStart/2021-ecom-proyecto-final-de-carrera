package ecom

class TrendsController {
    def trendsService


    def listTrendsCountry() {

        def tendencias = trendsService.getTrendsCountryDB()
        [tendenciasPais:tendencias]
    }

    def saveTrendsCountry() {
        def saveOK = trendsService.saveTrendsCountry()
        if(saveOK) {
            [data:"Se guardo correctamente"]
        } else {
            [data:"Error al guardar"]
        }
    }

    def listTrendsCategory()
    {
        def criteria = Criteria.get(params.id)
        def tendencias = trendsService.getTrendsCategoryDB(criteria.category.idCategoryML)
        render(view: "listTrendsCategory",model:[tendenciasCategory:tendencias])
    }

    def saveTrendsCategory()
    {
        def data
        Searches search = Searches.get(params.search)
        List<Criteria> lista = search.criteria.toList();
        Executions exe = Executions.get(params.ejecucion)
        try {
            for(Criteria c : lista) {

                def saveOK = trendsService.saveTrendsCategory(c,exe)
                if (saveOK) {
                    data = "Se guardo correctamente"
                } else {
                    data = "Error al guardar"
                }
            }
        }
        catch (Exception e)
        {println (e.getMessage())}
        render(view: "saveTrendsCategory",model:[data: data])
    }

    def blacklistWords()
    {
        Searches search = Searches.get(params.search)
        List<Criteria> lista = search.criteria.toList();
        Long ejecucion = Long.parseLong(params.ejecucion)
        for(Criteria c : lista) {
            trendsService.blackListWordsCriteria(c,ejecucion)
        }
    }
}
