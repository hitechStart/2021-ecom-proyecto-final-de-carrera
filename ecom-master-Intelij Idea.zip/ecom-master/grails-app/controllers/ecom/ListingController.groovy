package ecom

import ar.edu.unlam.connector.ecom.constants.SearchType


class ListingController {

    def listingService
    def paymentService
    def shippingService
    def wordService

    def index() {
        String userId = "241171a5-a607-4482-881c-ee330e6a12a8" //recuperar de login
        Users user = Users.findByIdUser(userId)
        def ejecuciones = listingService.getUserExecutions(userId)
        [user:user,searches:ejecuciones]
    }

    def list() {
        def ejecucion = listingService.getExecution(Long.parseLong(params.id))
        def busqueda = ejecucion.getSearch()
        //def criterias = busqueda.getCriteria().toList()
        def total = listingService.getListingTotal(ejecucion)
        def max = 10
        if(params.max != null)
            max = Integer.parseInt(params.max)
        def offset = 0
        if(params.offset != null)
            offset = Integer.parseInt(params.offset)
        def listado = listingService.getListing(ejecucion,max,offset)
        [total:total,listings:listado,search_name:busqueda.getDescription()]
    }

    def listingsByCriteria() {
        Executions ejecucion = listingService.getExecution(Long.parseLong(params.exe))
        List<Criteria> criterias = new ArrayList<Criteria>()
        Criteria criteriaABuscar=Criteria.get(params.id)
        criterias.add(criteriaABuscar)
        def total = listingService.getListingByCriteriasTotal(criterias, ejecucion)
        def max = 10
        if(params.max != null)
            max = Integer.parseInt(params.max)
        def offset = 0
        if(params.offset != null)
            offset = Integer.parseInt(params.offset)
        def listado = listingService.getListingByCriterias(criterias, ejecucion ,max,offset)
        render(view: "listCriteria",model:[total:total,listings:listado,search_name:criteriaABuscar.category.nameML])
    }

    def criteriaBySearch(){
        Searches search = Searches.get(params.search)
        render(view: "criteria",model:[criteria:search.criteria, exe:params.ejecucion])
    }

    def executeProccess(def params){
        Executions execution = Executions.get(params.id)
        if (execution.search.searchType == SearchType.CATEGORY)
            listingService.proccessListingCategoryByExecution(execution)
        else{
            listingService.proccessListingCategoryByExecution(execution)
        }
    }


    def listingPayment(def params) {
        List<ItemGrouping> data = paymentService.getGrupos()
        def listado = null
        def total = 0
        def ejecucion = params.id
        def max = 10
        if(params.max != null)
            max = Integer.parseInt(params.max)
        def offset = 0
        if(params.offset != null)
            offset = Integer.parseInt(params.offset)
        if(ejecucion == null)
            ejecucion = params.ejecucion
        if(params.id_grupo != null){
            listado = listingService.getListingPorPayment(Integer.parseInt(params.id_grupo), Long.parseLong(params.ejecucion), params.groupType, max, offset)
            total = listingService.getListingPorPaymentTotal(Integer.parseInt(params.id_grupo), Long.parseLong(params.ejecucion), params.groupType)
        }
        //def paymentList = paymentService.getPaymentMethodsDB()
        render(view: "listingGroup",model:[data: data, group:params.id_grupo, ejecucion:ejecucion, listing:listado, total: total, vista:"listingPayment", vista2: "medios de pago", groupType:"PAYMENT_METHODS"])
    }

    def listingShipping(def params) {
        List<ItemGrouping> data = shippingService.getGrupos()
        def listado = null
        def total = 0
        def ejecucion = params.id
        def max = 10
        if(params.max != null)
            max = Integer.parseInt(params.max)
        def offset = 0
        if(params.offset != null)
            offset = Integer.parseInt(params.offset)
        if(ejecucion == null)
            ejecucion = params.ejecucion
        if(params.id_grupo != null){
            listado = listingService.getListingPorShipping(Integer.parseInt(params.id_grupo), Long.parseLong(params.ejecucion), params.groupType, max, offset)
            total = listingService.getListingPorShippingTotal(Integer.parseInt(params.id_grupo), Long.parseLong(params.ejecucion), params.groupType)
        }
        //def paymentList = paymentService.getPaymentMethodsDB()
        render(view: "listingGroup",model:[data: data, group:params.id_grupo, ejecucion:ejecucion, listing:listado, total: total, vista:"listingShipping", vista2: "forma de envío", groupType:"SHIPPING_METHODS"])
    }

    def list2(def params){
        //def words = listingService.getRelatedWords(Long.parseLong(params.idEjecucion),params.idListing)
        def precision = listingService.getPrecisionBusquedaListing(params.idListing,Long.parseLong(params.idEjecucion))
        def listingDesc = listingService.getListingNombre(params.idListing)
        def total = listingService.getRelatedListingTotal(params.idListing, Long.parseLong(params.idEjecucion),precision)

        def max = 10
        if(params.max != null)
            max = Integer.parseInt(params.max)
        def offset = 0
        if(params.offset != null)
            offset = Integer.parseInt(params.offset)
        def listado = listingService.getRelatedListing(params.idEjecucion as Long,params.idListing,max,offset,precision)
        [total:total,listings:listado, itemRelacion: listingDesc]
    }


    def price2 ()
    {
        Double cotaInferior
        Double cotaSuperior
        def listado
        int i
        def ejecucion = listingService.getExecution(Long.parseLong(params.exe))

        def criteria = Criteria.get(params.id)

        def rango = listingService.getListingPrice(ejecucion,criteria)
        cotaInferior=rango[0]*0.1
        cotaSuperior =rango[0]*0.9
        listado = listingService.getPurguePrice(ejecucion,criteria,cotaInferior,cotaSuperior)
        /*
        cotaInferior=rango[1]/5
        cotaSuperior =rango[0]*5

        for(i=0;i<100;i++)
                    {

                        listado = listingService.getPurguePrice(ejecucion,criteria,cotaInferior,cotaSuperior)
                        cotaInferior=listado[2]/5
                        cotaSuperior =listado[2]*5
                    }
        */
        //render(view:"price",model: [categoria:criteria.category.nameML,promedio:Math.round(listado[2]),minimo:rango[1],maximo:rango[0]])
        render(view:"price",model: [categoria:criteria.category.nameML,promedio:Math.round(listado[2]),minimo:listado[1],maximo:listado[0]])

    }

    def reducirRangoPublicacionesPorPrecio ()
    {
        Double cotaInferior
        Double cotaSuperior
        Double publicaciones80porcien
        Double publicacionesFiltradas
        Double publicacionesFiltradasAnterior
        Double cotaInferiorAnterior
        Double cotaSuperiorAnterior

        def listado

        def ejecucion = listingService.getExecution(Long.parseLong(params.exe))

        def criteria = Criteria.get(params.id)

        def rango = listingService.getListingPriceElegible(ejecucion,criteria)

        /*saco cuanto es el 80% de las publicaciones*/
        publicaciones80porcien = Math.round(rango[3]*0.8)
        cotaInferior=rango[2]/2
        cotaSuperior =rango[2]*2

        listado = listingService.getPurguePrice(ejecucion,criteria,cotaInferior,cotaSuperior)
        publicacionesFiltradas=listado[3]

        while(publicaciones80porcien>listado[3])
        {
          /*me guardo el anterior por si me paso*/
            cotaInferiorAnterior=cotaInferior
            cotaSuperiorAnterior=cotaSuperior
            publicacionesFiltradasAnterior=publicacionesFiltradas

            /*muevo el rango del filtro*/
            cotaInferior=cotaInferior-(cotaInferior*0.05)
            cotaSuperior=cotaSuperior+(cotaSuperior*0.05)
            listado = listingService.getPurguePrice(ejecucion,criteria,cotaInferior,cotaSuperior)
            publicacionesFiltradas=listado[3]
        }

        /*valido que rango tiene mas publicaciones para despues usar en el procedure*/
        if(Math.abs(publicaciones80porcien-publicacionesFiltradas)>Math.abs(publicaciones80porcien-publicacionesFiltradasAnterior))
            {
                cotaInferior=cotaInferiorAnterior
                cotaSuperior=cotaSuperiorAnterior
            }


        //render(view:"price",model: [categoria:criteria.category.nameML,promedio:Math.round(listado[2]),minimo:rango[1],maximo:rango[0]])
        render(view:"price",model: [categoria:criteria.category.nameML,promedio:Math.round(listado[2]),minimo:listado[1],maximo:listado[0]])

    }





    def price ()
    {

        def listado
        int i
        def ejecucion = listingService.getExecution(Long.parseLong(params.exe))

        def criteria = Criteria.get(params.id)

        listado = listingService.getListingPriceElegible(ejecucion,criteria)


        //render(view:"price",model: [categoria:criteria.category.nameML,promedio:Math.round(listado[2]),minimo:rango[1],maximo:rango[0]])
        render(view:"price",model: [categoria:criteria.category.nameML,promedio:Math.round(listado[2]),minimo:listado[1],maximo:listado[0]])

    }


    def purgelistingByPrice()
    {

        def listado = listingService.getAllExecutionCriteria()
        for(def a : listado)
        {
            listingService.getPurguePriceProcedure(String.valueOf(a.getAt("ejecucion")),String.valueOf(a.getAt("criterio")))
        }


    }

    def executePurguePrice(def params)
    {
        Searches search = Searches.get(params.search)
        List<Criteria> lista = search.criteria.toList();
        for(Criteria c : lista) {
            listingService.getPurguePriceProcedure(params.ejecucion,c.idCriteria.toString());
        }
    }


    def getListingInformationByPermalink(def params){
        if (params.permalink){
            def listingAttributes = listingService.getListingInformationByPermalink(params.permalink)
            return listingAttributes + [success:true]
        }

    }


    def listPalabras(def params){
        def listingDesc = listingService.getListingNombre(params.idListing)
        def precision = wordService.getPrecisionBusquedaWords(params.idListing,Long.parseLong(params.idEjecucion))
        def total = wordService.getListMostUsedWordsTotal(params.idListing, Long.parseLong(params.idEjecucion),precision)

        def max = 10
        if(params.max != null)
            max = Integer.parseInt(params.max)
        def offset = 0
        if(params.offset != null)
            offset = Integer.parseInt(params.offset)

        def listado = wordService.getListMostUsedWords(params.idListing,Long.parseLong(params.idEjecucion), precision,max, offset)
        [total:total,listings:listado, itemRelacion: listingDesc]

    }

    def listVentas(def params){
        Listing l = Listing.findByIdMl(params.idListing)
        def salesFiltered = PurchaseOrder.findAllByListing(l)
        def listing = Listing.findByIdMl(params.idListing)
        def sales = PurchaseOrder.list()
        [sales:salesFiltered,listing:listing]

    }

    def executeGroupListing(def params){
        Searches search = Searches.get(params.search)
        List<Criteria> lista = search.criteria.toList();
        for(Criteria c : lista) {
            listingService.callProcedureSaveGrouping(c.idCriteria.toString(),params.ejecucion);
        }
    }

    def executeIndicadores(def params){
        Searches search = Searches.get(params.search)
        List<Criteria> lista = search.criteria.toList();
        for(Criteria c : lista) {
            listingService.callProcedureSaveIndicadores(c.idCriteria.toString(),params.ejecucion);
        }
    }

    def executePriceRange(def params){
        Searches search = Searches.get(params.search)
        List<Criteria> lista = search.criteria.toList();
        Double cotaInferior
        Double cotaSuperior
        Double publicaciones80porcien
        Double publicacionesFiltradas
        Double publicacionesFiltradasAnterior
        Double cotaInferiorAnterior
        Double cotaSuperiorAnterior

        def listado

        Executions ejecucion = listingService.getExecution(Long.parseLong(params.ejecucion))
        def rango = listingService.getListingPriceElegible(ejecucion,null)
        publicaciones80porcien = Math.round(rango[3]*0.8)
        cotaInferior=rango[2]-(rango[2]*0.1)
        cotaSuperior =rango[2]+(rango[2]*0.1)
        listado = listingService.getPurguePrice(ejecucion,null,cotaInferior,cotaSuperior)
        publicacionesFiltradas=listado[3]

        while(publicaciones80porcien>listado[3])
        {
            /*me guardo el anterior por si me paso*/
            cotaInferiorAnterior=cotaInferior
            cotaSuperiorAnterior=cotaSuperior
            publicacionesFiltradasAnterior=publicacionesFiltradas

            /*muevo el rango del filtro*/
            cotaInferior=cotaInferior-(cotaInferior*0.05)
            cotaSuperior=cotaSuperior+(cotaSuperior*0.05)
            listado = listingService.getPurguePrice(ejecucion,null,cotaInferior,cotaSuperior)
            publicacionesFiltradas=listado[3]
        }

        /*valido que rango tiene mas publicaciones para despues usar en el procedure*/
        if(Math.abs(publicaciones80porcien-publicacionesFiltradas)>Math.abs(publicaciones80porcien-publicacionesFiltradasAnterior))
        {
            cotaInferior=cotaInferiorAnterior
            cotaSuperior=cotaSuperiorAnterior
        }
        for(Criteria c : lista) {
            listingService.callProcedurePriceRange(c.idCriteria.toString(),params.ejecucion, (int)cotaInferior, (int)cotaSuperior);
        }
    }

    def executeAveragePriceDay(def params){
        Searches search = Searches.get(params.search)
        List<Criteria> lista = search.criteria.toList();
        for(Criteria c : lista) {
            listingService.callProcedureAveragePriceDay(c.idCriteria.toString(),params.ejecucion);
        }
    }

    def executeSalesCity(def params){
        Searches search = Searches.get(params.search)
        List<Criteria> lista = search.criteria.toList();
        for(Criteria c : lista) {
            listingService.callProcedureSalesCity(c.idCriteria.toString(),params.ejecucion);
        }
    }

    def executeWordCloud(def params){
        Searches search = Searches.get(params.search)
        List<Criteria> lista = search.criteria.toList();
        for(Criteria c : lista) {
            listingService.callProcedureWordCloud(params.ejecucion,c.idCriteria.toString());


        }
    }

    def executeTrendBar(def Params)
    { Searches search = Searches.get(params.search)
        List<Criteria> lista = search.criteria.toList();
        for(Criteria c : lista) {
            listingService.callProcedureWordBarTrends(params.ejecucion,c.idCriteria.toString());
        }
    }

    def executeTrendTree(def params){
        Searches search = Searches.get(params.search)
        List<Criteria> lista = search.criteria.toList();
        for(Criteria c : lista) {
            listingService.callProcedureTrendTree(params.ejecucion);
        }
    }

    def executeLlenarTendencias(def params)
    {
        Searches search = Searches.get(params.search)
        List<Criteria> lista = search.criteria.toList();
        for(Criteria c : lista)
            {
                listingService.callProcedureWordCloud(params.ejecucion,c.idCriteria.toString());
                listingService.callProcedureTrendTree(params.ejecucion);
                listingService.callProcedureWordBarTrends(params.ejecucion,c.idCriteria.toString());

            }
    }

    def executeWords(def params) {
        def ejecucion = listingService.getExecution(Long.parseLong(params.ejecucion))
        listingService.processListingWords(ejecucion);
    }

    def executeAll(def params){

        Searches search = Searches.get(params.search)
        List<Criteria> lista = search.criteria.toList();


        for(Criteria c : lista) {
            listingService.callProcedureSaveIndicadores(c.idCriteria.toString(),params.ejecucion);
            listingService.callProcedureSaveGrouping(c.idCriteria.toString(),params.ejecucion);
            listingService.callProcedureAveragePriceDay(c.idCriteria.toString(),params.ejecucion);
            listingService.callProcedureSalesCity(c.idCriteria.toString(),params.ejecucion);
            listingService.callProcedurePriceRange(c.idCriteria.toString(),params.ejecucion);
        }
    }

    def executeTopSellers(def params){

        listingService.executeTopSellerProcedure(params.ejecucion)
        listingService.topSellersInfo(params.ejecucion)
    }


    def executeProccessForSellers(def params){
        def vendedores = listingService.getSellers()
        vendedores.each {
                listingService.updateSeller(it)
        }

    }

    def executeLlenarMainDashboard(def params)
    {
        Searches search = Searches.get(params.search)

        listingService.callProcedureLlenarMainDashboard(search.user.idUser)
    }


}
