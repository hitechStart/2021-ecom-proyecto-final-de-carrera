package ecom

class PaymentController {
def paymentService

    def list() {

        def paymentList = paymentService.getPaymentMethodsDB()
        [paymentMethods:paymentList]
    }


    def save() {
        def saveOK = paymentService.savePaymentMethods()
        if(saveOK) {
            [data:"Se guardo correctamente"]
        } else {
            [data:"Error al guardar"]
        }


    }
}
