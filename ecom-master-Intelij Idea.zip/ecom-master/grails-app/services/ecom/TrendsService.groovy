package ecom

import ar.edu.unlam.connector.ecom.connectors.TrendsClient
import grails.transaction.Transactional
import groovy.sql.Sql
import org.apache.tools.ant.taskdefs.Exec

@Transactional
class TrendsService {

    def listingService
    def sessionFactory
    /*=======================================================================
    tendencias argentina
    =========================================================================*/
    def getTrendsCountry()
    {
        return TrendsClient.INSTANCE.getTendenciaPais()
    }
    def getAllTrendsCountryDB(){
        return TrendsCountry.findAll().toList()
    }

    def getTrendsCountryDB()
    {
        return TrendsCountry.findAll{ estado == true && cantidadPublicaciones>0}.sort{-it.cantidadPublicaciones}

    }
    def getTrendsCountryActivosDB()
    {
        return TrendsCountry.findAll { estado == true}
    }

    def disableTrendsCountry()
    {
        def activos = getTrendsCountryActivosDB()

        for (TrendsCountry recorrer : activos)
        {
            try {
            TrendsCountry tendencia = TrendsCountry.get(recorrer.idTrendsCountry)
            tendencia.estado = false
            tendencia.save()
            }
            catch (Exception e)
                {println (e.getMessage())}
        }

    }

    def saveTrendsCountry()
    {
        def date = new Date()

        /*desactivo los viejos*/
        disableTrendsCountry()

        TrendsCountry tendencias = null
        for (Object trends : getTrendsCountry()) {
            String palabrasTendencias = trends.getAt('keyword')
            Long cantidadPublicaciones = listingService.getListingTrendsCountry(palabrasTendencias)
            tendencias = new TrendsCountry(trends.getAt('keyword'),date,true,trends.getAt('url'),cantidadPublicaciones)

            if (!tendencias.save(failOnError: true)) {
                tendencias.errors.each {
                    println it
                    return false
                }
            }
        }
        return true
    }

    /*=======================================================================
    tendencias por categoria
    =========================================================================*/

    def getTrendsCategory(String idMlCategory)
    {

        return TrendsClient.INSTANCE.getTendenciaCategoria(idMlCategory)

    }

    def getTrendsCategoryActivosDB(String idMLCategoria)
    {
        return TrendsCategory.findAll { (estado == true) && (idCategoryML == idMLCategoria) }
    }

    def getTrendsCategoryDB(String idMLCategoria)
    {
        return TrendsCategory.findAll { (estado == true) && (idCategoryML == idMLCategoria) && cantidadPublicaciones>0 }.sort{-it.cantidadPublicaciones}
    }

    def disableTrendsCategory(String idMLCategory, Long ejecucion)
    {
        def sql = new Sql(sessionFactory.currentSession.connection())
        sql.execute("UPDATE trends_category SET estado=0 WHERE execution_id=" + ejecucion + " AND id_categoryml='" + idMLCategory + "'")
    }

    def saveTrendsCategory(Criteria criterio, Executions exe)
    {
        def date = new Date()
        String idCategory = criterio.category.idCategoryML
        disableTrendsCategory(idCategory, exe.idExecution)

        TrendsCategory tendencias = null
        try {

        int i = 1;
        for (Object trends : getTrendsCategory(idCategory)) {

            String palabrasTendencias = trends.getAt('keyword')

            def listado = listingService.getListingTrendsCategory(idCategory,palabrasTendencias,exe.idExecution,criterio.idCriteria)

            long cantidadPublicaciones= listado[0].getAt("contador")
            Double indicadorOportunidad=0
            long cantidadVentas=0
            if(listado[0].getAt("ventas"))
                cantidadVentas=listado[0].getAt("ventas")

            if (cantidadPublicaciones!=0 && cantidadVentas != 0)
                indicadorOportunidad= cantidadVentas/cantidadPublicaciones

            if(!cantidadPublicaciones)
                cantidadPublicaciones=0

            tendencias = new TrendsCategory(trends.getAt('keyword'),date,true,idCategory,trends.getAt('url'),cantidadPublicaciones,exe,i,cantidadVentas,indicadorOportunidad)
            i++
            if (!tendencias.save(failOnError: true)) {
                tendencias.errors.each {
                    println it
                    return false
                }
            }
        }
        }
        catch (Exception e)
        {println(e.getMessage())}
        return true
    }

    def blackListWordsCriteria(Criteria c, Long ejecucion)
    {
        if(c.searchCriteria != null && c.searchCriteria != '')
        {
            def words = c.searchCriteria
            def arrayWords = words.split(" ")
            arrayWords.each {
                def word = replaceWord(it)
                if (word.length() >= 3) {
                    chequearYGuardar(word,ejecucion)
                }
            }
        }

        for(CriteriaAttributes ca : c.criteriaAttributes)
        {
            def words = ca.nameAttributeValueML
            def arrayWords = words.split(" ")
            arrayWords.each {
                def word = replaceWord(it)
                if (word.length() >= 3) {
                    chequearYGuardar(word,ejecucion)
                }
            }
        }

        def words = c.category.nameML
        def arrayWords = words.split(" ")
        arrayWords.each {
            def word = replaceWord(it)
            if (word.length() >= 3) {
                chequearYGuardar(word,ejecucion)
            }
        }
    }

    def chequearYGuardar(String word, Long ejecucion)
    {
        String consulta = "SELECT COUNT(*) as contador FROM motor_blacklist_words WHERE word='"+ word+"' AND execution_id="+ejecucion;
        def sql = new Sql(sessionFactory.currentSession.connection())
        def listado = sql.rows(consulta)
        if(listado[0]["contador"] == 0) {
            consulta = "INSERT INTO motor_blacklist_words (version, word, execution_id) VALUES (0,'"+ word+"',"+ejecucion+")";
            def resultado = sql.execute(consulta);
            System.out.println(resultado)
        }
    }

    def replaceWord(String word) {
        word = word.replace('-', '')
        word = word.replace('_', '')
        word = word.replace('/', '')
        word = word.replace('(', '')
        word = word.replace(')', '')
        word = word.replace(':', '')
        word = word.replace(',', '')
        word = word.replace('!', '')
        word = word.replace('¡', '')
        word = word.replace('.', '')
        word = word.replace('+', '')
        word = word.replace('*', '')
        word = word.replace('á', 'a')
        word = word.replace('é', 'e')
        word = word.replace('í', 'i')
        word = word.replace('ó', 'o')
        word = word.replace('ú', 'u')
        word = word.replace(' ', '')
        word = word.trim()
        word = word.toLowerCase()
        return word
    }
}
