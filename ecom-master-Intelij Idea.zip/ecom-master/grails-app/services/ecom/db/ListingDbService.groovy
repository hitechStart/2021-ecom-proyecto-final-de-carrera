package ecom.db

import ecom.Address
import ecom.Category
import ecom.Criteria
import ecom.Executions
import ecom.Installment
import ecom.Listing
import ecom.Seller
import ecom.Shipping
import grails.transaction.Transactional

import java.time.Instant

@Transactional
class ListingDbService {

    def sellerDbService

    def saveListings(List<Map<String, Object>> listings, Executions execution, Criteria criteria) {
        Long now = System.currentTimeMillis()

        listings.each {
            Map<String, Object> sellerMap = it.get("seller")
            Map<String, Object> installmentMap = it.get("installments")
            Map<String, Object> addressMap = it.get("address")
            Map<String, Object> shippingMap = it.get("shipping")

            Seller seller = sellerDbService.getSeller(sellerMap)

            Installment installment = new Installment(
                    quantity: installmentMap.get("quantity"),
                    amount: installmentMap.get("amount"),
                    rate: installmentMap.get("rate"),
                    currencyId: installmentMap.get("currency_id")
            )

            Address address = new Address(
                    stateId: addressMap.get("state_id"),
                    stateName: addressMap.get("state_name"),
                    cityId: addressMap.get("city_id"),
                    cityName: addressMap.get("city_name")
            )

            Shipping shipping = new Shipping(
                    freeShipping: shippingMap.get("free_shipping"),
                    mode: shippingMap.get("mode"),
                    tags: shippingMap.get("tags"),
                    logisticType: shippingMap.get("logistic_type"),
                    storePickUp: shippingMap.get("store_pick_up")
            )

            new Listing(
                    idMl: it.get("id"),
                    siteId: it.get("site_id"),
                    title: it.get("title"),
                    price: it.get("price"),
                    currencyId: it.get("currency_id"),
                    availableQuantity: it.get("available_quantity"),
                    soldQuantity: it.get("sold_quantity"),
                    originalPrice: it.get("original_price"),
                    officialStoreId: it.get("official_store_id"),
                    catalogProductId: it.get("catalog_product_id"),
                    acceptsMercadopago: it.get("accepts_mercadopago"),
                    buyingMode: it.get("buying_mode"),
                    listingTypeId: it.get("listing_type_id"),
                    permalink: it.get("permalink"),
                    thumbnail: it.get("thumbnail"),
                    thumbnailId: it.get("thumbnail_id"),
                    orderBackend: it.get("order_backend"),
                    useThumbnailId: it.get("use_thumbnail_id"),
                    domainId: it.get("domain_id"),
                    stopTime: Instant.parse(it.get("stop_time")),
                    tags: it.get("tags"),
                    listingCondition: it.get("condition"),
                    address: address,
                    shipping: shipping,
                    installment: installment,
                    seller: seller,
                    category: Category.findByIdCategoryML(it.get("category_id")),
                    criteria: criteria,
                    execution: execution,
                    dateCreated: new Date()


            ).save(failOnError: true, flush: true)
        }


        Long end = System.currentTimeMillis()
        return end - now
    }

    def getAddressDbById(String addressId)

    {
        return Address.findAllByCityId(addressId)

    }

}

