package ecom.db

import ar.edu.unlam.connector.ecom.constants.OperationProcessType
import ecom.OperationLogs
import grails.transaction.Transactional

import java.time.Instant

@Transactional
class OperationLogsService {

    def saveSuccess(String source, OperationProcessType type, String description, Long resultQty ) {
        new OperationLogs(
                operationType: type,
                operationDate: Instant.now(),
                source: source,
                description: description,
                result: "SUCCESS",
                resultQty: resultQty,
                errorDescription: ""
        ).save(cascade:true,failOnError: true,flush: true)
    }

    def saveError(String source, OperationProcessType type, String errorDescription) {
        new OperationLogs(
                operationType: type,
                operationDate: Instant.now(),
                source: source,
                description: "",
                result: "ERROR",
                resultQty: 0,
                errorDescription: errorDescription
        ).save(cascade:true,failOnError: true,flush: true)
    }

    def saveException(String source, OperationProcessType type, String errorDescription) {
        new OperationLogs(
                operationType: type,
                operationDate: Instant.now(),
                source: source,
                description: "",
                result: "EXCEPTION",
                resultQty: 0,
                errorDescription: errorDescription
        ).save(cascade:true,failOnError: true,flush: true)
    }

}
