package ecom


import grails.transaction.Transactional
import ar.edu.unlam.connector.ecom.connectors.PaymentClient
@Transactional
class PaymentService {

    def getPaymentMethods() {
        return PaymentClient.INSTANCE.getPaymentMethods()
    }

    def getGrupos(){
        return ItemGrouping.findAllByGroupingType("PAYMENT_METHODS");
    }

    def getPaymentMethodsDB(){
        return PaymentMethods.findAll().toList()
    }

    def savePaymentMethods() {
        PaymentMethods medioPagos = null
        for (Object payment : getPaymentMethods()) {

            medioPagos = new PaymentMethods(payment.getAt('id'),payment.getAt('name'),payment.getAt('payment_type_id'))

            if (!medioPagos.save(failOnError: true)) {
                medioPagos.errors.each {
                    println it
                    return false
                }
            }
        }
        return true
    }

}
