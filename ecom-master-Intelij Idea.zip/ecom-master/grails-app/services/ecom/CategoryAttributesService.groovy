package ecom

import ar.edu.unlam.connector.ecom.connectors.CategoryAttributesClient
import grails.transaction.Transactional

@Transactional
class CategoryAttributesService {

    def getCategoryAttributes(String idCategory){
        return CategoryAttributesClient.INSTANCE.getCategoryAttributes (idCategory)
    }

    def getCategoryAttributesDB(){
        return CategoryAttributes.findAll().toList()
    }



    def saveCategoryAttributes(Category cat) {
            for(Object attributes : getCategoryAttributes(cat.idCategoryML)) {
                CategoryAttributes  atributos = new CategoryAttributes(cat,attributes.getAt('id'),attributes.getAt('name') ,attributes.getAt('value_type') ,attributes.getAt('attribute_group_id') ,attributes.getAt('attribute_group_name') )
                if (!atributos.save()) {
                    atributos.errors.each {
                        return false

                    }
                }
                for (Object valor : attributes.getAt('values')){
                    CategoryAttributeValues atributesValues = new CategoryAttributeValues(atributos,valor.getAt('id'), valor.getAt('name'))
                    if(!atributesValues.save()) {
                        atributesValues.errors.each {
                        return false
                        }
                    }
                }
            }

        return true
    }

}
