package ecom

import ar.edu.unlam.connector.ecom.connectors.ShippingClient
import grails.transaction.Transactional

@Transactional
class ShippingService {

    def getShippingMethods() {
        return ShippingClient.INSTANCE.getShippingMethods()
    }

    def getGrupos(){
        return ItemGrouping.findAllByGroupingType("SHIPPING_METHODS");
    }

    def getShippingMethodsDB(){
        return ShippingMethods.findAll().toList()
    }

    def saveShippingMethods() {
        ShippingMethods envios = null
        for (Object shipping : getShippingMethods()) {

            envios = new ShippingMethods(shipping.getAt('name'), shipping.getAt('status'), shipping.getAt('site_id'), null,null,shipping.getAt('company_id'),shipping.getAt('company_name'))

            if (!envios.save(failOnError: true)) {
                envios.errors.each {
                    println it
                    return false
                }
            }
        }
        return true
    }


}
