package ecom

import ar.edu.unlam.connector.ecom.connectors.CategoriesClient
import grails.transaction.Transactional

@Transactional
class CategoriesService {
    
    def getCategories(){
        return CategoriesClient.INSTANCE.getBaseCategories()
    }

    def getCategoriesDB(){
        return Category.findAll().toList()
    }



    def getCategoriesPadre(){
        return Category.findAllByLevel(1).toList()
    }

    def getCategoriesHijas(String id){
        def category = Category.get(id)
        def lista
        if(category != null)
            lista = Category.findAllByIdCategoryPadre(category.idCategoryML).toList()
        return lista
    }

    def getArbolSeleccionado(String id){
        Category cat = Category.get(id)
        String arbol = cat.nameML
        while (cat.idCategoryPadre != null) {
            cat = Category.findByIdCategoryML(cat.idCategoryPadre)
            arbol = cat.nameML + "->" + arbol
        }
        return arbol
    }

    def getCategoryById(String categoryId){
        return CategoriesClient.INSTANCE.getCategoryById(categoryId)
    }

    def getCategoriesTotal(){
        def total = Category.count()
        return total
    }

    def getFechaUltimaActualizacion(){
        def fecha = Category.list(max: 1, sort: "fechaUltimaActualizacion", order: "desc")
        return fecha.get(0).getFechaUltimaActualizacion()
    }

    def getCategoryIdPadre(String categoryId){
        Category cat = null
        cat = Category.get(categoryId);
        if(cat != null) {
            cat = Category.findByIdCategoryML(cat.idCategoryPadre)
            if (cat != null)
                return cat.idCategoryML
            else
                return "0"
        } else
            return "0"
    }


    def saveCategories(String fecha) {
        Category categoria = null
        for (Object cat : getCategories()) {
            def detalles = getCategoryById(cat.getAt("id"))
            categoria = new Category(null,cat.getAt("id"),cat.getAt("name"),detalles.get("total_items_in_this_category"),1, fecha,detalles.get("picture"),detalles.get("permalink"))
            if (!categoria.save()) {
                categoria.errors.each {
                    println(it)
                }
            }
        }
        return true
    }

    def updateCategoriesById(String id,String fecha)
    {

            Category categoriaActualizar = Category.get(id)
            def detalles = getCategoryById(id)
            if(detalles == null)
                return;

            categoriaActualizar.linkML=detalles.get("permalink")
            categoriaActualizar.pictureML=detalles.get("picture")
            categoriaActualizar.fechaUltimaActualizacion=fecha
            categoriaActualizar.save()

    }



    def saveChilds(Object cat, int level, String padre, String fecha)
    {
        Object[] children = cat.getAt("children_categories")
        for(Object child : children)
        {
            def detalles = getCategoryById(child.getAt("id"))
            saveChilds(detalles,level+1, cat.getAt("id"), fecha)
        }
        if(level  > 1) {
            def detalles = getCategoryById(cat.getAt("id"))
            Category categoria = new Category(padre, cat.getAt("id"), cat.getAt("name"), detalles.get("total_items_in_this_category"), level, fecha,detalles.get("picture"),detalles.get("permalink"))
            if (!categoria.save()) {
                categoria.errors.each {
                    println(it)
                }
            }
        }
    }

}
