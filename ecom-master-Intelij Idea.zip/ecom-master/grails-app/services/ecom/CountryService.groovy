package ecom

import ar.edu.unlam.connector.ecom.connectors.LocationClient
import grails.transaction.Transactional

@Transactional
class CountryService {

    def getCountries() {
        return LocationClient.INSTANCE.getCountries()
    }

    def getCountriesById(countryID) {
        return LocationClient.INSTANCE.getCountriesById(countryID)
    }

    def getCountriesDB()
    {return Country.findAll().toList()
    }

    def saveCountry()
    {
        Country pais = null
        /*recorro los paises*/
        try {
            for(Object country : getCountries())
            {
                /*tengo que obtener info del pais*/
            Object infoCountry = getCountriesById(country.getAt("id"))


            pais = new Country(infoCountry.getAt("id"),infoCountry.getAt("name"),infoCountry.getAt("currency_id"),infoCountry.getAt("geo_information").getAt("location").getAt("latitude"),infoCountry.getAt("geo_information").getAt("location").getAt("longitude"))

            if (!pais.save()) {
                pais.errors.each {
                    return false
                }
            }

            }
        }
        catch (Exception e)
        {println (e.getMessage())}

    }


    def saveArgentina()
    {
        Country pais = null
        /*recorro los paises*/
        try {

                /*tengo que obtener info del pais*/
                Object infoCountry = getCountriesById("AR")


                pais = new Country(infoCountry.getAt("id"),infoCountry.getAt("name"),infoCountry.getAt("currency_id"),infoCountry.getAt("geo_information").getAt("location").getAt("latitude"),infoCountry.getAt("geo_information").getAt("location").getAt("longitude"))

                if (!pais.save()) {
                    pais.errors.each {
                        return false
                    }
                }
            return true

            }

        catch (Exception e)
        {println (e.getMessage())}

    }


}