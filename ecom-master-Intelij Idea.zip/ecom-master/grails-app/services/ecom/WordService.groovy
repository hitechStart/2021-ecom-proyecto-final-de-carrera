package ecom

import groovy.sql.Sql

import java.util.regex.Matcher
import java.util.regex.Pattern


class WordService {

    def sessionFactory

    def getListMostUsedWordsTotal(String idML, Long idEjecucion, int precision) {
        def sql = new Sql(sessionFactory.currentSession.connection())
        def total = sql.rows("CALL TraerTotalPalabrasMasUsadas ('" + idML + "',"+precision+","+idEjecucion+");")
        return total[0]["contador"]
    }

    def getListMostUsedWords(String idML, Long idEjecucion, int precision, int max, int offset) {
        def sql = new Sql(sessionFactory.currentSession.connection())
        def rows = sql.rows("CALL TraerPalabrasMasUsadas ('" + idML + "',"+precision+","+idEjecucion+","+max+","+offset+");")
        return rows
    }


    def getPrecisionBusquedaWords(String idML, Long ejecucion) {
        def sql = new Sql(sessionFactory.currentSession.connection())

        def cantWords = sql.rows("SELECT COUNT(DISTINCT d.word) as contador FROM listing_words d LEFT JOIN " +
                "motor_blacklist_words mbw ON  mbw.word = d.word AND (mbw.execution_id = null or " +
                "mbw.execution_id = "+ ejecucion + ") WHERE d.listing_id_ml = '"+ idML+"' AND d.listing_execution_id = "+ ejecucion + " AND mbw.id IS NULL" )


        int precision = cantWords[0]["contador"]

        return (precision - 1)
    }

    /*def getListMostUsedWords(List<String> listado, Long idEjecucion)
    {
        String pattern
        Pattern p
        Matcher m



        List<String> words = ListingWords.createCriteria().list() {
            execution {
                eq("idExecution", idEjecucion)
            }
            listing{
                'in'("idMl", listado)
            }

            projections {
                property('word', 'word')
            }
        }


        def search = Executions.get(idEjecucion).search

        def criterias = Criteria.createCriteria().list() {
            eq("search",search)
            projections {
                distinct("searchCriteria")
            }
        }

        List<String> lfinal = new ArrayList<String>()
        for (String s : words)
        {
            pattern = "\\b"+ s+"\\b"
            p = Pattern.compile(pattern)
            for(String s2 : criterias) {
                m = p.matcher(s2.toLowerCase())
                if (!m.find()) {
                    lfinal.add(s)
                    break
                }
            }
        }

        List<Object> wordsCount = ListingWords.createCriteria().list() {
            'in'("word",lfinal)
            execution {
                eq('idExecution',idEjecucion)
            }
            projections {
                count("id", "contador")
                groupProperty('word', 'word')
            }
            order "contador", "desc"
        }

        return wordsCount
    }*/
}

