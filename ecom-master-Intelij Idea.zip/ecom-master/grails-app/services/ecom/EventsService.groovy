package ecom

import grails.transaction.Transactional

@Transactional
class EventsService {

    def serviceMethod() {

    }

    def getEventsDB(){
        return Events.findAll().toList()
    }

    def getEventDBById(Long id)
    {
        return Events.get(id)
    }

    def saveEvents(String name, Date fechaDesde, Date fechaHasta, Boolean estado) {

    Events evento = new Events(name,fechaDesde,fechaHasta,estado)
    if(!evento.save())
        {
            evento.errors.each {return false}
        }
     return true

    }

    def deleteEvents (Long id)
    {
        Events evento = Events.get(id)
        evento.delete()
    }

    def updateEvents(Long id,String name, Date fechaDesde, Date fechaHasta, Boolean estado)

    {
        Events evento = Events.get(id)

        if(name)
            {evento.name=name}
        if(fechaDesde)
            {evento.fechaDesde=fechaDesde}
        if(fechaHasta)
            {evento.fechaHasta=fechaHasta}

            evento.estado=estado

        evento.save()


    }
}
