package ecom

import ar.edu.unlam.connector.ecom.connectors.AuthClient
import grails.transaction.Transactional

@Transactional
class AccessTokenService {

    Auth tokenCache

    def getAccessToken(boolean refreshToken) {
        def tokenList = Auth.list()
        if (refreshToken) {
            Map token = AuthClient.INSTANCE.getAccessToken("1586142976127673", "mBboRFhUNrkkNGaShPUqvMxPVO2iL97r");

            if (tokenList == 0){
                tokenCache = new Auth(
                        clientId: "1586142976127673",
                        clientSecret: "mBboRFhUNrkkNGaShPUqvMxPVO2iL97r",
                        accessToken: token.get("access_token"),
                        tokenType: token.get("token_type"),
                ).save(failOnError: true,flush:true)
            }
            else{
                tokenCache = tokenList.get(0)
                tokenCache.accessToken = token.get("access_token")
                tokenCache.tokenType = token.get("token_type")
            }
        }
        else {
            if (tokenCache == null && tokenList.size() > 0)
                tokenCache = tokenList.get(0)
        }
        return tokenCache

    }
}
