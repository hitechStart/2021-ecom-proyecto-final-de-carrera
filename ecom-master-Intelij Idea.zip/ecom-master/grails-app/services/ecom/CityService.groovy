package ecom

import ar.edu.unlam.connector.ecom.connectors.LocationClient
import grails.transaction.Transactional

@Transactional
class CityService {
    def cityService
    def getCitiesById(citiesID) {
        return LocationClient.INSTANCE.getCitiesById(citiesID)
    }

    def getCityDB()
    {return City.findAll().toList()}

    def getCityDBByState(State state)
    {
        return City.findAllByState(state)

    }

    def getCityDBById(String id)
    {
        return City.get(id)
    }

    def saveCity()
    {
        try
        {   for(State state : State.findAll().toList())
            {Object infoStates = LocationClient.INSTANCE.getStatesById(state.getAt("idState"))
             //State estado = new State (null,infoStates.getAt("id"),infoStates.getAt("name"),null,null)
                for(Object ciudades : infoStates.getAt("cities") )
                {
                    City city = null
                    def infoDeCity = getCitiesById(ciudades.getAt("id"))
                    city = new City(state,infoDeCity.getAt("id"),infoDeCity.getAt("name"),infoDeCity.getAt("geo_information").getAt("location").getAt("latitude"),infoDeCity.getAt("geo_information").getAt("location").getAt("longitude"),infoDeCity.getAt("id"))

                    if (!city.save(flush : true)) {
                        city.errors.each {
                            return false
                        }
                    }


                }
            }

        }
        catch (Exception e)
        {println (e.getMessage())}





    }

def saveCityByState (String idState)
{
    try
    {

        Object infoStates = LocationClient.INSTANCE.getStatesById(idState)
        State state = State.get(idState)



        for(Object ciudades : infoStates.getAt("cities") )
        {
            City city = null
            def infoDeCity = getCitiesById(ciudades.getAt("id"))
            city = new City(state,infoDeCity.getAt("id"),infoDeCity.getAt("name"),infoDeCity.getAt("geo_information").getAt("location").getAt("latitude"),infoDeCity.getAt("geo_information").getAt("location").getAt("longitude"),infoDeCity.getAt("id"))

            if (!city.save(flush : true)) {
                city.errors.each {
                    return false
                }
            }


        }

        return true
    }
    catch(Exception e)
    {println (e.getMessage())}


}

    def saveCityByGob(String idState, String idGob) {

        try{

        /*traigo ciudades de la api del gobierno*/
        def listaCiudadesGob = LocationClient.INSTANCE.getCitiesArgentinaOfGobAr(idGob)
        /*me recupero el state*/
        State state = State.get(idState)
        /*recorro las localidades*/
        for (Object ciudades : listaCiudadesGob.getAt("localidades")) {
            String ciudadNormalizada = ciudades.getAt("nombre")
            String cadenaAuxiliar = ""


            for (String palabra : ciudadNormalizada.split(" ")) {
                cadenaAuxiliar += palabra.substring(0, 1).toUpperCase() + palabra.substring(1, palabra.length()).toLowerCase() + " ";
            }
            ciudadNormalizada = cadenaAuxiliar.trim();


            /*valido si ya la inserto ML*/
            def ciudadAux = getCity(state, ciudadNormalizada)

            if (ciudadAux) {
                /*si encontro me traigo lo q esta en la base*/
                City ciudadActualizar = null
                ciudadActualizar = City.get(ciudadAux)

                /*actualizo coordenadas y el id del gob*/
                ciudadActualizar.latitud = Double.valueOf(ciudades.getAt("centroide_lat"))
                ciudadActualizar.longitud = Double.valueOf(ciudades.getAt("centroide_lon"))
                ciudadActualizar.idCityGob = ("ID" + String.valueOf(ciudades.getAt("id")))
                ciudadActualizar.save()

            } else {
                /*si no lo encuentra ML, lo creo de 0*/
                City ciudad = null
                Double latitud = Double.valueOf(ciudades.getAt("centroide_lat"))
                Double longitud = Double.valueOf(ciudades.getAt("centroide_lon"))
                String id = ("ID" + String.valueOf( ciudades.getAt("id")))

                ciudad = new City(state, id ,ciudadNormalizada, latitud,longitud, id)

                if (!ciudad.save(flush: true)) {
                    ciudad.errors.each {
                        return false
                    }
                }
            }


        }
    }
        catch(Exception e)
        {println (e.getMessage())}


    }


    def getCity(State idState, String name) {
        def ciudades = null
        Boolean filtroElegible = 1
        try {
            ciudades = City.createCriteria().get(){

                /*hace el where*/
                eq("name",name)
                eq("state",idState)


                /*hace el select*/
                projections{

                    property("idCity","idCity")

                }

            }
        } catch (Exception e) {
            println(e.getMessage())
        }
        return ciudades
    }

    def deleteCity(String idCity)
    {
        City ciudad = City.get(idCity)
        ciudad.delete()
    }

    def updateCity(String idCity, String name, Double latitud, Double longitud)

    {
        City ciudad = City.get(idCity)

        if(name)
        {ciudad.name=name}
        if(latitud)
        {ciudad.latitud=latitud}
        if(longitud)
        {ciudad.longitud=longitud}



        ciudad.save()


    }

    def insertCity(String idState,String name, Double latitud, Double longitud) {
        String idCity
        String idGob
        State estado = State.get(idState)
        idCity=name
        idGob=name
        City ciudad = new City(estado,idCity,name,latitud,longitud,idGob)
        if(!ciudad.save())
        {
            ciudad.errors.each {return false}
        }
        return true

    }

}


