package ecom

class PurchaseService {

    def getSalesByListing(String idML, Long idEjecucion) {
        def listado = null
        try{
            listado = PurchaseOrder.createCriteria() {
                listing {
                    execution{
                        eq("idExecution", idEjecucion)
                    }
                }
                eq("idMl", idML)
            }
        }catch(Exception e)
        {
            println(e.getMessage())
        }
        return listado
    }


}

