package ecom.ar.edu.unlam.connector.ecom.connectors

import ar.edu.unlam.connector.ecom.constants.OperationProcessType
import ar.edu.unlam.connector.ecom.exceptions.ApiException
import ar.edu.unlam.connector.ecom.utils.JsonUtils
import ecom.Auth
import org.apache.http.HttpStatus
import org.apache.http.client.methods.CloseableHttpResponse
import org.apache.http.client.methods.HttpGet
import org.apache.http.client.methods.HttpUriRequest
import org.apache.http.impl.client.CloseableHttpClient
import org.apache.http.impl.client.HttpClients
import org.apache.http.util.EntityUtils

class QuestionsApiService {

    def operationLogsService
    def transactional = false
    CloseableHttpClient httpClient = HttpClients.createDefault();

    Map<String,Object> getQuestionsByListing(String itemId, Auth auth) {
        String uri = String.format("https://api.mercadolibre.com/questions/search?item=%s&api_version=4",itemId)
        HttpUriRequest request = new HttpGet(uri)
        request.setHeader("Content-Type", "application/json");
        request.setHeader("Authorization",String.format("Bearer %s",auth.getAccessToken()))
        CloseableHttpResponse response = null
        Map result = null
        int retries = 4
        boolean success = false
        try {
            while (!success && retries > 0){
                try{
                    response = httpClient.execute(request);
                    if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK){
                        result = JsonUtils.INSTANCE.toMap(EntityUtils.toString(response.getEntity()));
                        success = true;
                        //operationLogsService.saveSuccess(uri, OperationProcessType.QUESTIONS_BY_ITEM,response.getStatusLine().toString(), (long) result.get("total"));
                    }
                    else if (response.getStatusLine().getStatusCode() == HttpStatus.SC_UNAUTHORIZED || response.getStatusLine().getStatusCode() == HttpStatus.SC_FORBIDDEN )
                        throw new ApiException("get.questions.by.item.failed",String.format("Failed to get questions for item %s from mercadolibre api",itemId),HttpStatus.SC_INTERNAL_SERVER_ERROR);
                    else{
                        retries --;
                        Thread.sleep(100);
                        //operationLogsService.saveError(uri,OperationProcessType.QUESTIONS_BY_ITEM,response.getStatusLine().toString());
                    }
                }
                catch(Exception e){
                    retries --;
                    //operationLogsService.saveException(uri,OperationProcessType.QUESTIONS_BY_ITEM,e.getMessage());
                    try {
                        Thread.sleep(100);
                    }
                    catch(InterruptedException ex){
                    }
                }
            }
            if (!success)
                throw new ApiException("get.questions.by.item.failed",String.format("Failed to get questions for item %s from mercadolibre api",itemId),HttpStatus.SC_INTERNAL_SERVER_ERROR)
            else
                return result
        }
        finally {
            try {
                if (response != null)
                    response.close()
            }
            catch(Exception e){
                throw new ApiException("get.questions.by.item.failed",String.format("Failed to get questions for item %s from mercadolibre api",itemId),HttpStatus.SC_INTERNAL_SERVER_ERROR)
            }
        }


    }

}
