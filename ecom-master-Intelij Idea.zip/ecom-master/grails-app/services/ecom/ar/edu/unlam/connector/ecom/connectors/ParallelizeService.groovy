package ecom.ar.edu.unlam.connector.ecom.connectors

import ar.edu.unlam.connector.ecom.utils.Partition
import groovyx.gpars.GParsPool


class ParallelizeService {

    def itemsVisitsApiService
    def reviewsApiService
    def questionsApiService
    def transactional = false
    def getListingDataInParallel(def listings,def auth) {

        Map<String, Object> questions = Collections.synchronizedMap(new HashMap<Long, Object>())
        Map<String, Object> reviews = Collections.synchronizedMap(new HashMap<Long, Object>())
        Map<String, Object> visits = Collections.synchronizedMap(new HashMap<Long, Object>())

        try{
            GParsPool.withPool(30) {
                listings.eachParallel {
                    questions.put(it.get("id"),questionsApiService.getQuestionsByListing(it.get("id"),auth).get("total"))
                    reviews.put(it.get("id"),reviewsApiService.getReviewsByItem(it.get("id"),auth))
                }

                Partition.ofSize(listings*.id,10).eachParallel {
                    for(String itId : it) {
                        visits.putAll(itemsVisitsApiService.getVisitsByItems(itId, auth))
                    }
                }

            }
        }
        catch(Exception e){
            System.out.println("Errorrrr")
            log.error("Error")
        }

        return [questions:questions,reviews:reviews,visits:visits]

    }
}
