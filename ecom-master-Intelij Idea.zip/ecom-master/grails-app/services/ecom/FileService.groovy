package ecom

import ar.edu.unlam.connector.ecom.utils.GZipUtils
import ar.edu.unlam.connector.ecom.utils.JsonUtils
import groovy.io.FileType
import org.apache.commons.lang.StringUtils

import java.text.DateFormat
import java.text.SimpleDateFormat
import java.time.Instant
import java.util.stream.Collectors

class FileService {

    def transactional = false

    def countInstallment = 604500
    def countShipping = 604500
    def countAddress = 604500
    def countWords = 0

    def saveListings(def listings, Executions execution) {

        File directory = new File("imports");
        if (!directory.exists())
            directory.mkdir()

        def sellersFile = "imports/sellers_${execution.idExecution}.csv"
        def listingsFile = "imports/listings_${execution.idExecution}.csv"
        def installmentsFile = "imports/installments_${execution.idExecution}.csv"
        def shippingFile = "imports/shipping_${execution.idExecution}.csv"
        def addressFile = "imports/address_${execution.idExecution}.csv"
        /*def wordsFile = "imports/words_${execution.idExecution}.csv"*/
        FileWriter sellersWritter = new FileWriter(sellersFile)
        FileWriter listingsWriter = new FileWriter(listingsFile)
        FileWriter installmentsWriter = new FileWriter(installmentsFile)
        FileWriter shippingWriter = new FileWriter(shippingFile)
        FileWriter addressWriter = new FileWriter(addressFile)
       /* FileWriter wordsWriter = new FileWriter(wordsFile)*/
        BufferedWriter sellerBuffer = new BufferedWriter(sellersWritter)
        BufferedWriter listingBuffer = new BufferedWriter(listingsWriter)
        BufferedWriter installmentBuffer = new BufferedWriter(installmentsWriter)
        BufferedWriter shippingBuffer = new BufferedWriter(shippingWriter)
        BufferedWriter addressBuffer = new BufferedWriter(addressWriter)
       /* BufferedWriter wordsBuffer = new BufferedWriter(wordsWriter)*/

        listings.each {
            Map<String, Object> sellerMap = it.get("seller")
            def seller = mapSeller(sellerMap)
            def listing = mapListing(it)
            def installment = mapInstallment(it)
            def shipping = mapShipping(it)
            def address = mapAddress(it)
            /*def words = mapWords(it)*/

           /* words.each {
                wordsBuffer.write(String.format("|||0|||%s|||%s|||%d\n", it.getAt("listingId"), it.getAt("word"), execution.idExecution))
            }*/
            sellerBuffer.write(String.format("%d|||%d|||0|||%s|||%s|||%s|||%s|||%s|||%s\n", execution.idExecution, seller.idMl, seller.carDealer, seller.permalink, seller.realStateAgency, seller.registrationDate, seller.tags,seller.sellerType).replaceAll("null", ""))
            listingBuffer.write(String.format("%d|||%s|||0|||%s|||%d|||%s|||%s|||%s|||%d|||%s|||%s|||%s|||%s|||%s|||%d|||%d|||%f|||%s|||%f|||%d|||%s|||%d|||%s|||%s|||%s|||%s|||%s|||%s|||%d|||%d|||%d|||%f|||%d\n",
                    execution.idExecution, listing.idMl, listing.acceptsMercadopago, listing.availableQuantity, listing.buyingMode, listing.catalogProductId,
                    listing.categoryId, listing.criteriaId, listing.currencyId, listing.dateCreated, listing.domainId,
                    listing.listingCondition, listing.listingTypeId, listing.officialStoreId, listing.orderBackend, listing.originalPrice as Double,
                    listing.permalink, listing.price as Double, listing.sellerId, listing.siteId, listing.soldQuantity, listing.stopTime,
                    listing.tags, listing.thumbnail, listing.thumbnailId, listing.title, listing.useThumbnailId, listing.totalQuestions, listing.visitsQuantity, listing.reviews, listing.ratingAverage, execution.idExecution).replaceAll("null", ""))

            if(installment != null) {
                installmentBuffer.write(String.format("%d|||%d|||%f|||%s|||%s|||%d|||%f|||%d\n", installment.id, installment.version,
                        installment.amount as Double, installment.currencyId, installment.listingId,
                        installment.quantity, installment.rate as Double, execution.idExecution).replaceAll("null", ""))
            }
                shippingBuffer.write(String.format("%d|||%d|||%s|||%s|||%s|||%s|||%s|||%s|||%d\n",
                    shipping.id, shipping.version, shipping.freeShipping, shipping.listingId, shipping.logisticType,
                    shipping.mode, shipping.storePickUp, shipping.tags, execution.idExecution).replaceAll("null", ""))

            addressBuffer.write(String.format("%d|||%d|||%s|||%s|||%s|||%s|||%s|||%d\n", address.id, address.version,
                    address.cityId, address.cityName, address.listingId, address.stateId, address.stateName, execution.idExecution).replaceAll("null", ""))
        }

        sellerBuffer.flush()
        sellerBuffer.close()

        listingBuffer.flush()
        listingBuffer.close()

        installmentBuffer.flush()
        installmentBuffer.close()

        shippingBuffer.flush()
        shippingBuffer.close()

        addressBuffer.flush()
        addressBuffer.close()
    }

    def saveOrders(def ordersPath, Executions execution) {

        File directory = new File("imports");
        if (!directory.exists())
            directory.mkdir()

        def ordersFile = "imports/orders_orders.csv"
        FileWriter ordersWritter = new FileWriter(ordersFile)
        BufferedWriter ordersBuffer = new BufferedWriter(ordersWritter)

        def dir = new File(ordersPath)
        dir.eachFileRecurse(FileType.FILES) { file ->
            file.eachLine {
                if (!StringUtils.isBlank(it)) {
                    def json = JsonUtils.INSTANCE.toMap(it)
                    Map item = json.get("Item")
                    Map compressedValue = item.get("compressed_value")
                    def compressedValueJson = GZipUtils.INSTANCE.uncompressString(compressedValue.get("B"))
                    if (!compressedValueJson.startsWith("[")){
                        for(int i = 19; i < 25; i++){
                            def order = mapOrder(JsonUtils.INSTANCE.toMap(compressedValueJson),i)
                            try {
                                ordersBuffer.write(String.format("|||%s|||%d|||%d|||%d|||%s|||%s|||%s|||%f|||%s|||%s|||%f|||%d|||%s|||%s|||%s|||%s|||%s|||%s|||%f|||%d|||%s|||%d|||%s|||%d|||%s|||%s|||%s|||%f|||%f|||%s|||%s|||%s|||%s|||%s|||%s\n",
                                        order.listing_id_ml,
                                        order.listing_execution_id,
                                        order.version,
                                        order.buyer_id,
                                        order.buying_mode,
                                        order.date_created,
                                        order.fulfilled,
                                        order.full_unit_price,
                                        order.listing_type_id,
                                        order.logistic_type,
                                        order.paid_amount,
                                        order.quantity,
                                        order.receiver_city_id,
                                        order.receiver_country,
                                        order.receiver_state_id,
                                        order.sender_city_id,
                                        order.sender_country,
                                        order.sender_state_id,
                                        order.shipping_cost,
                                        order.shipping_method_id,
                                        order.shipping_mode,
                                        order.shipping_option_id,
                                        order.shipping_option_name,
                                        order.shipping_service_id,
                                        order.shipping_status,
                                        order.status,
                                        order.tags,
                                        order.total_amount,
                                        order.unit_price,
                                        order.receiver_city_name,
                                        order.receiver_country_name,
                                        order.receiver_state_name,
                                        order.sender_city_name,
                                        order.sender_country_name,
                                        order.sender_state_name
                                ).replaceAll("null", ""))
                            } catch (Exception e)
                            {
                                System.out.println(compressedValueJson)
                            }
                        }

                    }

                }
            }
        }

        ordersBuffer.flush()
        ordersBuffer.close()
    }

    def mapOrder(def order, def executionId) {
        DateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", Locale.getDefault());
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        def dateCreated = order.date_created != null ? simpleDateFormat.parse(order.date_created) : null;

        def orderResponse = [
                listing_id_ml: order.order_items[0].item.id,
                listing_execution_id:executionId,
                version:0,
                buyer_id:order.buyer.id,
                buying_mode:order.buying_mode,
                date_created: order.date_created!= null ? dateCreated.format("yyyy-MM-dd HH:mm:ss") : null,
                fulfilled:order.fulfilled,
                full_unit_price: order.order_items[0].full_unit_price as Double,
                listing_type_id: order.order_items[0].listing_type_id,
                logistic_type: order.new_shipping_information?.logistic_type,
                paid_amount: order.paid_amount as Double,
                quantity: order.order_items[0].quantity,
                receiver_city_id:order?.new_shipping_information?.receiver_address?.city?.id,
                receiver_country_id:order?.new_shipping_information?.receiver_address?.country?.id,
                receiver_state_id:order?.new_shipping_information?.receiver_address?.state?.id,
                sender_city_id:order?.new_shipping_information?.sender_address?.city?.id,
                sender_country_id:order?.new_shipping_information?.sender_address?.country?.id,
                sender_state_id:order?.new_shipping_information?.sender_address?.state?.id,
                shipping_cost:order.shipping_cost as Double,
                shipping_method_id:order?.new_shipping_information?.shipping_option?.shipping_method_id,
                shipping_mode:order?.new_shipping_information?.mode,
                shipping_option_id:order?.new_shipping_information?.shipping_option?.id,
                shipping_option_name:order?.new_shipping_information?.shipping_option?.name,
                shipping_service_id:order?.new_shipping_information?.service_id,
                shipping_status:order?.new_shipping_information?.status,
                status:order?.status,
                tags:order.get("tags") != null ? ((List) order.get("tags")).stream().collect(Collectors.joining(",")) : "",
                total_amount:order.total_amount as Double,
                unit_price:order.order_items[0].unit_price as Double,
                receiver_city_name:order?.new_shipping_information?.receiver_address?.city?.name,
                receiver_country_name:order?.new_shipping_information?.receiver_address?.country?.name,
                receiver_state_name:order?.new_shipping_information?.receiver_address?.state?.name,
                sender_city_name:order?.new_shipping_information?.sender_address?.city?.name,
                sender_country_name:order?.new_shipping_information?.sender_address?.country?.name,
                sender_state_name:order?.new_shipping_information?.sender_address?.state?.name,
        ]
        return orderResponse
    }

    def mapWords(def listing) {
        List<Object> listWord = new ArrayList<>()
        def words = listing.get("title")
        def arrayWords = words.split(" ")
        arrayWords.each {
            def word = replaceWord(it)
            if (word.length() >= 3) {
                listWord.add([version  : 0,
                              listingId: listing.get("id"),
                              word     : word])
            }
        }
        return listWord
    }

    def mapInstallment(def listing) {
        if(listing != null) {
            def installment = [
                    id        : countInstallment++,
                    version   : 0,
                    amount    : (listing.get("installments") != null ? listing.get("installments").get("amount") as Double : "0" as Double),
                    currencyId: (listing.get("installments") != null ? listing.get("installments").get("currency_id") : ""),
                    listingId : listing.get("id"),
                    quantity  : (listing.get("installments") != null ? listing.get("installments").get("quantity") : 0),
                    rate      : (listing.get("installments") != null ?  listing.get("installments").get("rate") : "0" as Double)
            ]
            return installment
        } else {
            return null;
        }

    }

    def mapShipping(def listing) {
        def shipping = [
                id          : countShipping++,
                version     : 0,
                freeShipping: listing.get("shipping").get("free_shipping") ?: "",
                listingId   : listing.get("id"),
                logisticType: listing.get("shipping").get("logistic_type"),
                mode        : listing.get("shipping").get("mode") ?: "",
                storePickUp : listing.get("shipping").get("store_pick_up") ?: "",
                tags        : listing.get("shipping").get("tags") != null ? ((List) listing.get("shipping").get("tags")).stream().collect(Collectors.joining(",")) : ""
        ]
        return shipping

    }

    def mapAddress(def listing) {
        def address = [
                cityId   : listing.get("address").get("city_id"),
                cityName : listing.get("address").get("city_name"),
                id       : countAddress++,
                listingId: listing.get("id"),
                stateId  : listing.get("address").get("state_id"),
                stateName: listing.get("address").get("state_name"),
                version  : 0
        ]
        return address

    }

    def mapSeller(def sellerMap) {
        DateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", Locale.getDefault());
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        def registrationDate = sellerMap.get("registration_date") != null ? simpleDateFormat.parse(sellerMap.get("registration_date")) : null;
        def seller = [
                idMl            : sellerMap.get("id"),
                permalink       : sellerMap.get("permalink") != null && sellerMap.get("permalink") != "" ? sellerMap.get("permalink") : "null",
                registrationDate: registrationDate != null ? registrationDate.format("yyyy-MM-dd HH:mm:ss") : null,
                carDealer       : sellerMap.get("car_dealer") ?: "",
                realStateAgency : sellerMap.get("real_estate_agency") ?: "",
                tags            : sellerMap.get("tags") != null ? ((List) sellerMap.get("tags")).stream().collect(Collectors.joining(",")) : "",
                sellerType      : sellerMap.get("seller_reputation") != null ? sellerMap.get("seller_reputation").get("power_seller_status") : ""
        ]
        return seller

    }

    def mapListing(listingMap) {
        def seller = [
                idMl              : listingMap.get("id"),
                acceptsMercadopago: listingMap.get("accepts_mercadopago") ?: "",
                availableQuantity : listingMap.get("available_quantity"),
                buyingMode        : listingMap.get("buying_mode"),
                catalogProductId  : listingMap.get("catalog_product_id"),
                categoryId        : listingMap.get("category_id"),
                criteriaId        : listingMap.get("criteria_id"),
                currencyId        : listingMap.get("currency_id"),
                dateCreated       : new Date().format("yyyy-MM-dd HH:mm:ss"),
                domainId          : listingMap.get("domain_id"),
                executionId       : listingMap.get("execution_id"),
                listingCondition  : listingMap.get("condition"),
                listingTypeId     : listingMap.get("listing_type_id"),
                officialStoreId   : listingMap.get("official_store_id"),
                orderBackend      : listingMap.get("order_backend"),
                originalPrice     : listingMap.get("original_price"),
                permalink         : listingMap.get("permalink"),
                price             : listingMap.get("price"),
                sellerId          : listingMap.get("seller").get("id"),
                siteId            : listingMap.get("site_id"),
                soldQuantity      : listingMap.get("sold_quantity"),
                stopTime          : Date.from(Instant.parse(listingMap.get("stop_time"))).format("yyyy-MM-dd HH:mm:ss"),
                tags              : listingMap.get("tags") != null ? ((List) listingMap.get("tags")).stream().collect(Collectors.joining(",")) : "",
                thumbnail         : listingMap.get("thumbnail"),
                thumbnailId       : listingMap.get("thumbnail_id"),
                title             : listingMap.get("title"),
                totalQuestions    : listingMap.get("total_questions"),
                visitsQuantity    : listingMap.get("visits"),
                reviews           : listingMap.get("reviews"),
                ratingAverage     : listingMap.get("rating_average"),
                useThumbnailId    : listingMap.get("use_thumbnail_id") ?: ""

        ]
        return seller
    }

    def saveListingWords(List<Listing> listado, Executions execution) {
        File directory = new File("imports");
        if (!directory.exists())
            directory.mkdir()

        def wordsFile = "imports/words_${execution.idExecution}.csv"
        FileWriter wordsWritter = new FileWriter(wordsFile)
        BufferedWriter wordsBuffer = new BufferedWriter(wordsWritter)
        String words = ""
        for (Object l : listado) {
            words = l[1]
            def arrayWords = words.split(" ")
            arrayWords.each {
                def word = replaceWord(it)
                if (word.length() >= 3) {
                    wordsBuffer.write(String.format("|||0|||%s|||%s|||%d\n", l[0], word, execution.idExecution))
                }
            }
        }
        wordsBuffer.flush()
        wordsBuffer.close()
        wordsWritter.close()
    }

    def replaceWord(String word) {
        if(word.isNumber())
            return ""
        word = word.replace('-', '')
        word = word.replace('_', '')
        word = word.replace('/', '')
        word = word.replace('(', '')
        word = word.replace(')', '')
        word = word.replace(':', '')
        word = word.replace(',', '')
        word = word.replace('!', '')
        word = word.replace('¡', '')
        word = word.replace('.', '')
        word = word.replace('+', '')
        word = word.replace('*', '')
        word = word.replace('á', 'a')
        word = word.replace('é', 'e')
        word = word.replace('í', 'i')
        word = word.replace('ó', 'o')
        word = word.replace('ú', 'u')
        word = word.replace(' ', '')
        word = word.trim();
        word = word.toLowerCase()
        return word
    }
}
