package ecom

import ar.edu.unlam.connector.ecom.connectors.LocationClient
import ecom.CountryService
import grails.transaction.Transactional

@Transactional
class StateService {

    def getStatesById(stateID) {
        return LocationClient.INSTANCE.getStatesById(stateID)
    }

    def getStateDB()
    {return State.findAll().toList()}

    def getStateDBByCountry(String idCountry)
    {
        def pais = Country.get(idCountry)
        return State.findAllByCountry(pais)
    }

    def saveState()

    {

        try{
        for(Country pais : Country.findAll().toList())
            {   Object infoCountry = LocationClient.INSTANCE.getCountriesById(pais.getAt("idCountry"))

                for(Object states : infoCountry.getAt("states"))
                     {   State estado = null

                         def infoDeEstado = getStatesById(states.getAt("id"))

                         estado = new State(pais,infoDeEstado.getAt("id"),infoDeEstado.getAt("name"),infoDeEstado.getAt("geo_information").getAt("location").getAt("latitude"),infoDeEstado.getAt("geo_information").getAt("location").getAt("longitude"),null)


                         if (!estado.save()) {

                             estado.errors.each {
                                 return false
                            }
                        }
                    }
            }
    }
        catch (Exception e)
        {println (e.getMessage())}
    }

    def saveStateByCountry(String idCountry)
    {
        try
        {

           Object infoCountry = LocationClient.INSTANCE.getCountriesById(idCountry)

            Country country = Country.get(idCountry)
            for(Object states : infoCountry.getAt("states"))
            {

                def infoDeEstado = getStatesById(states.getAt("id"))

                State estados = new State(country,infoDeEstado.getAt("id"),infoDeEstado.getAt("name"),infoDeEstado.getAt("geo_information").getAt("location").getAt("latitude"),infoDeEstado.getAt("geo_information").getAt("location").getAt("longitude"),null)


                if (!estados.save(flush : true)) {

                    estados.errors.each {
                        return false
                    }
                }

            }
            return true

    }
    catch (Exception e)
    {println (e.getMessage())}}

    /*metodo que conecta con las apis del gobierno */


    def saveStatesGobAr()
    {
        try

    {
        Country country = Country.get('AR')
        def estadosGobierno = LocationClient.INSTANCE.getStatesArgentinaOfGobAr()


        for(Object states : estadosGobierno.getAt("provincias"))
        {

            String nombre;
            if(states.getAt("iso_id") == "AR-C")
            {
                nombre="Capital Federal"
            }
            else
            {
                nombre= states.getAt("nombre")
            }
            State estados = new State(country,states.getAt("iso_id"),nombre,states.getAt("centroide").getAt("lat"),states.getAt("centroide").getAt("lon"),states.getAt("id"))


            if (!estados.save(flush : true)) {

                estados.errors.each {
                    return false
                }
            }

        }
        return true

    }
    catch (Exception e)
    {println (e.getMessage())}}
}
