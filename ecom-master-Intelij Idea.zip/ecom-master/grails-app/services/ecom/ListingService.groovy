package ecom

import ar.edu.unlam.connector.ecom.configurations.Configurations
import ar.edu.unlam.connector.ecom.constants.ExecutionStatus
import ar.edu.unlam.connector.ecom.constants.OperationProcessType
import ar.edu.unlam.connector.ecom.exceptions.ApiException
import ar.edu.unlam.connector.ecom.utils.JsonUtils
import groovy.sql.Sql
import org.apache.http.HttpStatus
import org.apache.http.client.methods.CloseableHttpResponse
import org.apache.http.client.methods.HttpGet
import org.apache.http.client.methods.HttpUriRequest
import org.apache.http.impl.client.CloseableHttpClient
import org.apache.http.impl.client.HttpClients
import org.apache.http.util.EntityUtils
import org.hibernate.criterion.CriteriaSpecification



import java.util.regex.Matcher
import java.util.regex.Pattern


class ListingService {

    def fileService
    def listingApiService
    def accessTokenService
    def parallelizeService
    def sessionFactory

    def transactional = true

    CloseableHttpClient httpClient = HttpClients.createDefault();

    def getListingInformationByPermalink(String permalink){
        def pattern = ~/.*\\/.*\\/MLA-(\d*).*/
        if (pattern.matcher(permalink).matches()){
            String id = "MLA" + pattern.matcher(permalink)[0][1]
            def item =  listingApiService.getItemById(id)
            def title = item.title
            def categoryId = item.category_id
            def condition = item.condition
            def catalogProductId = item.catalog_product_id
            def attributes = []
            item.attributes.each{
                attributes.add(["id":it.id,"name":it.name,"value_id":it.value_id,"value_name":it.value_name])
            }
            return [title:title,category_id:categoryId,condition:condition,catalog_product_id:catalogProductId,attributes:attributes]
        }
        else {
            return "Link no machea una publicacion"
        }
    }

    def proccessListingCategoryByExecution(Executions execution) {
        Auth auth = accessTokenService.getAccessToken(true)
        boolean requestCompleted = false
        def resultsTotal = []
        int executionTotal = 0
        for (criteria in execution.getSearch().getCriteria()) {
            int total = 1
            int offset = 0

            def startTime,endTime
            while (offset < total) {

                Map searchResult
                while (requestCompleted == false) {
                    try {
                        startTime = System.currentTimeMillis()
                        searchResult = listingApiService.searchListingByCategoryAndQuery(criteria, offset, Configurations.SEARCH_OFFSET_SIZE, auth)
                        requestCompleted = true
                    }
                    catch (ApiException e) {
                        if (e.getStatusCode() == 401 || e.getStatusCode() == 403) {
                            auth = accessTokenService.getAccessToken(true)
                        }
                    }
                }
                requestCompleted = false
                List listings = (List) searchResult.get("results")
                Map paging = searchResult.get("paging")
                total = paging.get("total")
                resultsTotal.addAll(listings)
                offset += listings.size()

                def parallelResult = parallelizeService.getListingDataInParallel(listings,auth)
                endTime = System.currentTimeMillis()
                println("Executing offset " + offset + " of total " + total + " time " + (endTime - startTime))
                listings.each {
                    def review = parallelResult.reviews.get(it.get("id"))
                    it.criteria_id = criteria.idCriteria
                    it.execution_id = execution.idExecution
                    it.total_questions = parallelResult.questions.get(it.get("id"))
                    it.reviews = review.get("paging").get("total")
                    it.rating_average = review.get("rating_average") as Double
                    it.visits = parallelResult.visits[it.id]

                }

                if(offset% 50 == 0)
                    fileService.saveListings(resultsTotal,execution)
            }
            criteria.quantity = total
            executionTotal += total
            criteria.save(failOnError: true,flush:true)

        }
        execution.listingQtty = executionTotal
        execution.executionStatus = ExecutionStatus.COMPLETED
        execution.dateFinished = new Date()
        fileService.saveListings(resultsTotal,execution)
        execution.save(failOnError: true,flush: true)
    }

    def getListingByCriterias(List<Criteria> criterias,Executions execution, Integer max, Integer offset) {
        List<Listing> listado = null
        try {
           // listado = Listing.findAllByCriteriaInList(criterias, [max: max, offset: offset])
            listado = Listing.createCriteria().list(max: max, offset: offset) {
                'in'("criteria",criterias)
                eq("execution",execution)
            }
       } catch (Exception e) {
           println(e.getMessage())
       }
        return listado
    }

    def getListing(Executions execution, Integer max, Integer offset) {
        List<Listing> listado = null
        try {
            listado = Listing.findAllByExecution(execution, [max: max, offset: offset])
        } catch (Exception e) {
            println(e.getMessage())
        }
        return listado
    }

    def getListingPrice(Executions ejecucion, Criteria criteria) {
        def listado = null
        try {
            listado = Listing.createCriteria().get(){

                /*hace el where*/
                eq("criteria",criteria)
                eq("execution",ejecucion)

                /*hace el select*/
                projections{

                    max("price")
                    min("price")
                    avg("price")
                    count()
                }

            }
        } catch (Exception e) {
            println(e.getMessage())
        }
        return listado
    }

    def getListingPriceElegible(Executions ejecucion, Criteria criteria) {
        def listado = null
        Boolean filtroElegible = 1
        try {

            if(criteria != null ) {
                listado = Listing.createCriteria().get() {

                    /*hace el where*/
                    eq("criteria", criteria)
                    eq("execution", ejecucion)
                    eq("elegible", filtroElegible)

                    /*hace el select*/
                    projections {

                        max("price")
                        min("price")
                        avg("price")
                        count()
                    }

                }
            } else {
                listado = Listing.createCriteria().get() {
                    eq("execution", ejecucion)
                    eq("elegible", filtroElegible)

                    /*hace el select*/
                    projections {

                        max("price")
                        min("price")
                        avg("price")
                        count()
                    }

                }
            }
        } catch (Exception e) {
            println(e.getMessage())
        }
        return listado
    }


    def getPurguePrice(Executions ejecucion, Criteria criteria, Double precioMinimo, Double precioMaximo) {
        def listado = null
        Boolean filtroElegible = 1
        try {
            if(criteria != null) {
                listado = Listing.createCriteria().get() {

                    /*hace el where*/
                    eq("criteria", criteria)
                    eq("execution", ejecucion)
                    ge("price", precioMinimo)
                    le("price", precioMaximo)
                    eq("elegible", filtroElegible)


                    /*hace el select*/
                    projections {

                        max("price")
                        min("price")
                        avg("price")
                        count()
                    }

                }
            } else {
                listado = Listing.createCriteria().get() {

                    /*hace el where*/
                    eq("execution", ejecucion)
                    ge("price", precioMinimo)
                    le("price", precioMaximo)
                    eq("elegible", filtroElegible)


                    /*hace el select*/
                    projections {

                        max("price")
                        min("price")
                        avg("price")
                        count()
                    }
                }
            }
        } catch (Exception e) {
            println(e.getMessage())
        }
        return listado
    }



def getAllExecutionCriteria()
    {

        List <Listing> listado = null
       try {
            listado = Listing.createCriteria().list(){
                resultTransformer (CriteriaSpecification.ALIAS_TO_ENTITY_MAP)
                projections {
                    groupProperty ('execution','execution')
                    groupProperty ('criteria','criteria')
                    property ('execution.idExecution','ejecucion')
                    property ('criteria.idCriteria','criterio')


                }
                order "execution", "asc"

            }
           return listado
        }
            catch (Exception e) {
                println(e.getMessage())
            }

    }

    def getListingByCriteriasTotal(List<Criteria> criterias, Executions execution) {
        //def cantidad = Listing.countByCriteriaInList(criterias)
        def cantidad = Listing.createCriteria().count() {
            'in'("criteria",criterias)
            eq("execution",execution)
        }
        return cantidad
    }

    def getListingTotal(Executions execution) {
        def cantidad = Listing.countByExecution(execution)
        return cantidad
    }

    def getExecution(Long idExec) {
        Executions e = Executions.get(idExec)
        return e
    }

    def getListingByExecution(Executions execution) {
        def listado = null
        try {
             listado = Listing.createCriteria().list() {
                   eq("execution", execution)
                   eq("elegible", true)
                   projections {
                       property('idMl', 'idMl')
                       property('title','title')
                   }
            }
        } catch(Exception e)
        {
            println(e.getMessage())
        }
        return listado
    }

    def getListingNombre(String listing) {
        def listado = ""
        try {
            listado = Listing.createCriteria().get() {
                eq("idMl", listing)
                projections {
                    property('title','title')
                }
            }
        } catch(Exception e)
        {
            println(e.getMessage())
        }
        return listado
    }

    def existsWordforExecution(Executions execution) {

        def total = 0
        try {
            total = ListingWords.countByExecution(execution)
        } catch(Exception e)
        {
            println(e.getMessage())
        }
        return total
    }

    def getListingPorPayment(Integer payment, Long ejecucion, String groupType, Integer max, Integer offset){
        def listado = null
        def listing_type = ItemGrouping.createCriteria().get(){
            eq("groupingType",groupType)
            eq("idGrouping",payment)
            projections {
                property("nameML","nameML")
            }
        }
        try{
            listado = Listing.createCriteria().list(max:max, offset:offset) {
                execution{
                    eq("idExecution", ejecucion)
                }
                eq("listingTypeId", listing_type)
                projections {
                    property('idMl', 'idMl')
                    property('title', 'title')
                    property('price', 'price')
                }
            }
        }catch(Exception e)
        {
            println(e.getMessage())
        }
        return listado
    }

    def getListingPorPaymentTotal(Integer payment, Long ejecucion, String groupType){
        def listado = null
        def listing_type = ItemGrouping.createCriteria().get(){
            eq("groupingType",groupType)
            eq("idGrouping",payment)
            projections {
                property("nameML","nameML")
            }
        }
        try{
            listado = Listing.createCriteria().count() {
                execution{
                    eq("idExecution", ejecucion)
                }
                eq("listingTypeId", listing_type)
                projections {
                    property('idMl', 'idMl')
                    property('title', 'title')
                    property('price', 'price')
                }
            }
        }catch(Exception e)
        {
            println(e.getMessage())
        }
        return listado
    }

    def processListingWords(Executions execution) {
        def listado = getListingByExecution(execution)
        if (listado != null) {
            fileService.saveListingWords(listado, execution)
        }
    }

    def getRelatedWords(Long ejecucion, String idML){
        String pattern
        Pattern p
        Matcher m
        List<String> words = ListingWords.createCriteria().list() {
            execution {
                eq("idExecution", ejecucion)
            }
            listing{
                eq("idMl", idML)
            }
            projections {
                property('word', 'word')
            }
        }


        def search = Executions.get(ejecucion).search

        def criterias = Criteria.createCriteria().list() {
            eq("search",search)
            projections {
                distinct("searchCriteria")
            }
        }

        List<String> lfinal = new ArrayList<String>()
        for (String s : words)
        {
            pattern = "\\b"+ s+"\\b"
            p = Pattern.compile(pattern)
            for(String s2 : criterias) {
                m = p.matcher(s2.toLowerCase())
                if (!m.find()) {
                    lfinal.add(s)
                    break
                }
            }
        }

        def wordsCount = ListingWords.createCriteria().list() {
            'in'("word",lfinal)
            execution {
                eq("idExecution", ejecucion)
            }
            projections {
                count("id", "contador")
                groupProperty('word', 'word')
            }
            order "contador", "desc"
        }

        return wordsCount
    }

    /*def getRelatedListing(Long idEjecucion,List<Object> listado, Integer max, Integer offset) {
        List<Object> listaAnd
        try {
            listaAnd  = listado.subList(0,2)
        } catch(Exception e) {
            println (e.getMessage())
            listaAnd  = listado.subList(0,1)
        }
        List<Object> listaOr
        try {
            listaOr = listado.subList(2, listado.size())
        } catch (Exception e)
        {
            println(e.getMessage())
            listaOr = null
        }
        List<Listing> cListado = Listing.createCriteria().list(max: max, offset: offset) {
                execution {
                    eq("idExecution", idEjecucion)
                }
                and {
                    listaAnd.each {
                        ilike("title","%"+it[1]+"%")
                    }
                    if(listaOr != null) {
                        or {
                           and {

                           }
                            listaOr.each {
                                ilike("title", "%" + it[1] + "%")
                            }
                        }
                    }
                }
        }
        return cListado
    }*/

    def getRelatedListing(Long idEjecucion, String idML, Integer max, Integer offset, int precision) {

        def sql = new Sql(sessionFactory.currentSession.connection())
        def rows = sql.rows("CALL TraerPublicacionesRelacionadas ('" + idML + "',"+precision+","+idEjecucion+","+max+","+offset+");")
        return rows
    }

    def getListingPorShipping(Integer shippingId, Long ejecucion, String groupType, Integer max, Integer offset){
        def listado = null
        def tipo_shipping = ItemGrouping.createCriteria().get(){
            eq("groupingType",groupType)
            eq("idGrouping",shippingId)
            projections {
                property("nameML","nameML")
            }
        }
        List<String> listaWhere = tipo_shipping.split(",")
        try{
            listado = Listing.createCriteria().list(max:max, offset:offset) {
                execution{
                    eq("idExecution", ejecucion)
                }
                shipping {
                        or {
                            for(String s: listaWhere) {
                                ilike("mode","%"+s+"%")
                                ilike("tags","%"+s+"%")
                            }
                        }
                }
                projections {
                    property('idMl', 'idMl')
                    property('title', 'title')
                    property('price', 'price')
                }
            }
        }catch(Exception e)
        {
            println(e.getMessage())
        }
        return listado
    }

    def getListingPorShippingTotal(Integer shippingId, Long ejecucion, String groupType){
        def listado = null
        def tipo_shipping = ItemGrouping.createCriteria().get(){
            eq("groupingType",groupType)
            eq("idGrouping",shippingId)
            projections {
                property("nameML","nameML")
            }
        }
        List<String> listaWhere = tipo_shipping.split(",")
        try{
            listado = Listing.createCriteria().count() {
                execution{
                    eq("idExecution", ejecucion)
                }
                shipping {
                        or {
                            for(String s: listaWhere) {
                                ilike("mode","%"+s+"%")
                                ilike("tags","%"+s+"%")
                            }
                        }
                }
                projections {
                    property('idMl', 'idMl')
                    property('title', 'title')
                    property('price', 'price')
                }
            }
        }catch(Exception e)
        {
            println(e.getMessage())
        }
        return listado
    }

    /*def getRelatedListingTotal(List<Object> listado, Long ejecucion) {
        List<Object> listaAnd
        try {
            listaAnd  = listado.subList(0,2)
        } catch(Exception e) {
            listaAnd  = listado.subList(0,1)
        }
        List<Object> listaOr
        try {
            listaOr = listado.subList(2, listado.size())
        } catch (Exception e)
        {
            listaOr = null
        }
        def total = Listing.createCriteria().count() {
            execution {
                eq("idExecution", ejecucion)
            }
            and {
                listaAnd.each {
                    ilike("title","%"+it[1]+"%")
                }
                if(listaOr != null) {
                    or {
                        eq("id", "-1")
                        listaOr.each {
                            ilike("title", "%" + it[1] + "%")
                        }
                    }
                }
            }
        }
        return total
    }*/

    def getPrecisionBusquedaListing(String idML, Long ejecucion) {
        def sql = new Sql(sessionFactory.currentSession.connection())

        def cantWords = sql.rows("SELECT COUNT( DISTINCT d.word) as contador FROM listing_words d LEFT JOIN " +
                "motor_blacklist_words mbw ON  mbw.word = d.word AND (mbw.execution_id = null or " +
                "mbw.execution_id = "+ ejecucion + ") WHERE d.listing_id_ml = '"+ idML+"' AND d.listing_execution_id = "+ ejecucion + " AND mbw.id IS NULL" )


        int precision = (cantWords[0]["contador"] / 2)

        return precision
    }

    def getRelatedListingTotal(String idML, Long ejecucion, int precision) {

        def sql = new Sql(sessionFactory.currentSession.connection())
        def total = sql.rows("CALL TraerTotalPublicacionesRelacionadas ('" + idML + "',"+precision+","+ejecucion+");")
        return total[0]["contador"]
    }

    List<String> getListingRelated(Long idEjecucion, String idListing) {
        String pattern
        Pattern p
        Matcher m

        List<String> words = ListingWords.createCriteria().list() {
            execution {
                eq("idExecution", idEjecucion)
            }
            listing{
                eq("idMl", idListing)
            }
            projections {
                property('word', 'word')
            }
        }


        def search = Executions.get(idEjecucion).search

        def criterias = Criteria.createCriteria().list() {
            eq("search",search)
            projections {
                distinct("searchCriteria")
            }
        }

        List<String> lfinal = new ArrayList<String>()
        for (String s : words)
        {
            pattern = "\\b"+ s+"\\b"
            p = Pattern.compile(pattern)
            for(String s2 : criterias) {
                m = p.matcher(s2.toLowerCase())
                if (!m.find()) {
                    lfinal.add(s)
                    break
                }
            }
        }

        List<Object> wordsCount = ListingWords.createCriteria().list() {
            'in'("word",lfinal)
            execution {
                eq('idExecution',idEjecucion)
            }
            projections {
                count("id", "contador")
                groupProperty('word', 'word')
            }
            order "contador", "desc"
        }

        List<Object> listaAnd
        try {
            listaAnd  = wordsCount.subList(0,2)
        } catch(Exception e) {
            listaAnd  = wordsCount.subList(0,1)
        }
        List<Object> listaOr
        try {
            listaOr = wordsCount.subList(2, wordsCount.size())
        } catch (Exception e)
        {
            listaOr = null
        }

        List<String> listingRelated = Listing.createCriteria().list() {
            execution {
                eq("idExecution", idEjecucion)
            }
            and {
                listaAnd.each {
                    ilike("title","%"+it[1]+"%")
                }
                if(listaOr != null) {
                    or {
                        eq("id", "-1")
                        listaOr.each {
                            ilike("title", "%" + it[1] + "%")
                        }
                    }
                }
            }
            projections{
                property('idMl', 'idMl')
            }
        }
        return listingRelated

    }

    def getListingById(String idListing)
    {
        return Listing.get(idListing)
    }




    def getListingPorZone(String cityId, Long ejecucion, Integer max, Integer offset){
        def listado = null

        try{
            listado = Listing.createCriteria().list(max:max, offset:offset) {
                execution{
                    eq("idExecution", ejecucion)
                }

                    address {

                        eq("cityId", cityId)
                    }

                projections {
                    property('idMl', 'idMl')
                    property('title', 'title')
                    property('price', 'price')
                }
            }
        }catch(Exception e)
        {
            println(e.getMessage())
        }
        return listado
    }

    def getListingPorZoneTotal(String idCity, Long ejecucion){
        def listado = null

        try{
            listado = Listing.createCriteria().count() {
                execution{
                    eq("idExecution", ejecucion)
                }
                address {

                        eq("cityId", idCity)
                }
                projections {
                    property('idMl', 'idMl')
                    property('title', 'title')
                    property('price', 'price')
                }
            }
        }catch(Exception e)
        {
            println(e.getMessage())
        }
        return listado
    }

    def getGroupsZone()
    {
        return Address.findAll().toList()
    }

    def getUserExecutions(String userId){
        def listado = null

        try{
            listado = Executions.createCriteria().list() {
                resultTransformer(CriteriaSpecification.ALIAS_TO_ENTITY_MAP)
                search {
                    user {
                        eq("idUser", userId)
                    }
                }
                projections {
                    search {
                        property("idSearch", "idSearch")
                        property("description","description")
                        property("searchType","searchType")
                    }
                    property("idExecution","idExecution")
                    property("executionStatus","executionStatus")
                    property("dateCreated","dateCreated")
                    property("dateFinished","dateFinished")
                }
                order("idExecution","asc")
            }
        }catch(Exception e)
        {
            println(e.getMessage())
        }
        return listado
    }

    def getListingTrendsCategory(String idCategory, String palabrasTendencias, Long ejecucion, Long idCriteria)
    {
        def listado
        Category cat = Category.get(idCategory)
        List<String> palabrasBuscar = new ArrayList<String>();
        String where = ""
        def palabrasSplit= palabrasTendencias.split(' ')
        palabrasSplit.each {
            def word = replaceWord(it)
            if(word.length() >= 3) {
                palabrasBuscar.add(word)
                where+= "lw.word ='" + word+"' OR "
            }
        }
        try{

            String consulta = "SELECT COUNT(*) as contador, sum(vendidos) as ventas FROM (SELECT listing_id_ml, COUNT(DISTINCT word), l.sold_quantity as vendidos" +
                    " FROM ecom.listing_words lw" +
                    " INNER JOIN listing l ON l.id_ml = lw.listing_id_ml AND l.execution_id = lw.listing_execution_id" +
                    " WHERE l.category_id = '" + cat.idCategoryML + "' AND (" + where + " 1=2)  AND lw.listing_execution_id = "+ ejecucion +" AND l.criteria_id = "+ idCriteria +
                    " GROUP BY listing_id_ml" +
                    " HAVING COUNT(DISTINCT word) = "+palabrasBuscar.size()+") a";

            def sql = new Sql(sessionFactory.currentSession.connection())
            listado = sql.rows(consulta);
        }
        catch(Exception e)
        {println e.getMessage()
        }
        return listado
    }


    def callProcedureSaveGrouping(String criteriaId, String ejecucionId) {
        def sql = new Sql(sessionFactory.currentSession.connection())
        sql.execute("CALL LlenarFrontListingGrouping(" + ejecucionId + "," + criteriaId + ");");
    }

    def callProcedureSaveIndicadores(String criteriaId, String ejecucionId) {
        def sql = new Sql(sessionFactory.currentSession.connection())
        sql.execute("CALL LlenarFrontListingIndicador(" + ejecucionId + "," + criteriaId + ");");
    }

    def callProcedurePriceRange(String criteriaId, String ejecucionId, int rangoDesde, int rangoHasta) {
        def sql = new Sql(sessionFactory.currentSession.connection())
        sql.execute("CALL LlenarPriceRangeGrouping(" + ejecucionId + "," + criteriaId + "," + rangoDesde + "," + rangoHasta + ");");
    }


    def callProcedureAveragePriceDay(String criteriaId, String ejecucionId) {
        def sql = new Sql(sessionFactory.currentSession.connection())
        sql.execute("CALL LlenarAveragePricePerDay(" + criteriaId + "," + ejecucionId + ");");
	}

    def callProcedureSalesCity(String criteriaId, String ejecucionId) {
        def sql = new Sql(sessionFactory.currentSession.connection())
        sql.execute("CALL LlenarFrontSalesPerCity(" + ejecucionId + "," + criteriaId + ");");
    }

    def getPurguePriceProcedure(String ejecucion, String criteria)
    {
        def sql = new Sql(sessionFactory.currentSession.connection())
        sql.execute("CALL ObtenerMediaPrecio(" + ejecucion + "," + criteria + ");");
    }

    def callProcedureWordCloud(String ejecucion, String criteria)
    {
        def sql = new Sql(sessionFactory.currentSession.connection())
        sql.execute("CALL LlenarTablaWordCloud(" + ejecucion + "," + criteria + ");")
    }

    def executeTopSellerProcedure(String ejecucion) {
        def sql = new Sql(sessionFactory.currentSession.connection())
        sql.execute("CALL LlenarTopSellers(" + ejecucion + ");")
    }

    def topSellersInfo(String ejecucion)
    {
        def sql = new Sql(sessionFactory.currentSession.connection())
        def rows = sql.rows("SELECT DISTINCT SellerId FROM front_top_sellers WHERE ExecutionId = " + ejecucion)
        Auth auth = accessTokenService.getAccessToken(true)
        boolean requestCompleted = false
        rows.each {
            String id = it["SellerId"]

            Map searchResult
            while (requestCompleted == false) {
                try {
                    searchResult = listingApiService.searchSellerInfo(id, auth)
                    requestCompleted = true
                }
                catch (ApiException e) {
                    if (e.getStatusCode() == 401 || e.getStatusCode() == 403) {
                        auth = accessTokenService.getAccessToken(true)
                    }
                }
            }
            List results = (List) searchResult.getAt("results")
            if(results.size() > 0) {
                def sellerReputation = results.get(0).getAt("seller").getAt("seller_reputation")
                def transactions = sellerReputation.getAt("transactions")
                def sellerType = sellerReputation.getAt("power_seller_status")
                def metrics = sellerReputation.getAt("metrics")
                sql.execute("UPDATE front_top_sellers SET ParameterValue='" + transactions.getAt("canceled") + "' WHERE ExecutionId=" + ejecucion + " AND SellerId='" + id + "' AND ParameterName='CancelacionesHistorico'")
                sql.execute("UPDATE front_top_sellers SET ParameterValue='" + transactions.getAt("ratings").getAt("negative") + "' WHERE ExecutionId=" + ejecucion + " AND SellerId='" + id + "' AND ParameterName='RatingNegativo'")
                sql.execute("UPDATE front_top_sellers SET ParameterValue='" + transactions.getAt("ratings").getAt("positive") + "' WHERE ExecutionId=" + ejecucion + " AND SellerId='" + id + "' AND ParameterName='RatingPositivo'")
                sql.execute("UPDATE front_top_sellers SET ParameterValue='" + transactions.getAt("ratings").getAt("neutral") + "' WHERE ExecutionId=" + ejecucion + " AND SellerId='" + id + "' AND ParameterName='RatingNeutral'")
                sql.execute("UPDATE front_top_sellers SET ParameterValue='" + (metrics.getAt("claims").getAt("excluded") != null ? metrics.getAt("claims").getAt("excluded").getAt("real_rate") : metrics.getAt("claims").getAt("rate")) + "' WHERE ExecutionId=" + ejecucion + " AND SellerId='" + id + "' AND ParameterName='ClaimsRate'")
                sql.execute("UPDATE front_top_sellers SET ParameterValue='" + (metrics.getAt("claims").getAt("excluded") != null ? metrics.getAt("claims").getAt("excluded").getAt("real_value") : metrics.getAt("claims").getAt("value")) + "' WHERE ExecutionId=" + ejecucion + " AND SellerId='" + id + "' AND ParameterName='ClaimsValue'")
                sql.execute("UPDATE front_top_sellers SET ParameterValue='" + (metrics.getAt("delayed_handling_time").getAt("excluded") != null ? metrics.getAt("delayed_handling_time").getAt("excluded").getAt("real_rate") : metrics.getAt("delayed_handling_time").getAt("rate")) + "' WHERE ExecutionId=" + ejecucion + " AND SellerId='" + id + "' AND ParameterName='DelayedRate'")
                sql.execute("UPDATE front_top_sellers SET ParameterValue='" + (metrics.getAt("delayed_handling_time").getAt("excluded") != null ? metrics.getAt("delayed_handling_time").getAt("excluded").getAt("real_value") : metrics.getAt("delayed_handling_time").getAt("value")) + "' WHERE ExecutionId=" + ejecucion + " AND SellerId='" + id + "' AND ParameterName='DelayedValue'")
                sql.execute("UPDATE front_top_sellers SET ParameterValue='" + (metrics.getAt("cancellations").getAt("excluded") != null ? metrics.getAt("cancellations").getAt("excluded").getAt("real_rate") : metrics.getAt("cancellations").getAt("rate")) + "' WHERE ExecutionId=" + ejecucion + " AND SellerId='" + id + "' AND ParameterName='CancellationRate'")
                sql.execute("UPDATE front_top_sellers SET ParameterValue='" + (metrics.getAt("cancellations").getAt("excluded") != null ? metrics.getAt("cancellations").getAt("excluded").getAt("real_value") : metrics.getAt("cancellations").getAt("value")) + "' WHERE ExecutionId=" + ejecucion + " AND SellerId='" + id + "' AND ParameterName='CancellationValue'")
                sql.execute("UPDATE front_top_sellers SET ParameterValue='" + sellerType + "' WHERE ExecutionId=" + ejecucion + " AND SellerId='" + id + "' AND ParameterName='TipoVendedor'")
            }
            requestCompleted = false
        }

    }

    def callProcedureWordBarTrends(String ejecucion, String criteria)
    {
        def sql = new Sql(sessionFactory.currentSession.connection())
        sql.execute("CALL LlenarFrontBarChartOportunity(" + ejecucion + "," + criteria + ");");
    }

    def callProcedureTrendTree(String ejecucion)
    {
        def sql = new Sql(sessionFactory.currentSession.connection())
        sql.execute("CALL LlenarFrontTrends(" + ejecucion + ");");
    }

    def callProcedureLlenarMainDashboard(String idUser)
    {
        def sql = new Sql(sessionFactory.currentSession.connection())
        sql.execute("CALL LlenarMainDashboard(" + idUser + ");");
    }

    def getListingTrendsCountry(String palabrasTendencias)
    {
        def listado

        List<String> palabrasBuscar = palabrasTendencias.split(' ')
        try{
            listado = Listing.createCriteria().count(){


                    for(String s: palabrasBuscar) {
                        ilike("title","%"+s+"%")


                }



            }}
        catch(Exception e)
        {println e.getMessage()
        }
        return listado
    }

    def replaceWord(String word) {
        word = word.replace('-', '')
        word = word.replace('_', '')
        word = word.replace('/', '')
        word = word.replace('(', '')
        word = word.replace(')', '')
        word = word.replace(':', '')
        word = word.replace(',', '')
        word = word.replace('!', '')
        word = word.replace('.', '')
        word = word.replace('+', '')
        word = word.replace('*', '')
        word = word.replace('á', 'a')
        word = word.replace('é', 'e')
        word = word.replace('í', 'i')
        word = word.replace('ó', 'o')
        word = word.replace('ú', 'u')
        word = word.toLowerCase()
        return word
    }

    def getSellers() {
        def listado = null

        try{
            listado = Seller.createCriteria().list() {
                eq("sellerType","")
                projections {
                    distinct("idMl")
                }
                setResultTransformer(CriteriaSpecification.ROOT_ENTITY)
            }
        }catch(Exception e)
        {
            println(e.getMessage())
        }
        return listado
    }

    def updateSeller(Long id)
    {
       String uri = "https://api.mercadolibre.com/users/" + id
        HttpUriRequest request = new HttpGet(uri)
        request.setHeader("Content-Type", "application/json")
        CloseableHttpResponse response = null
        Map result = null
        try{
            response = httpClient.execute(request);
            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK){
                result = JsonUtils.INSTANCE.toMap(EntityUtils.toString(response.getEntity()))
                def sql = new Sql(sessionFactory.currentSession.connection())
                sql.execute("UPDATE seller SET seller_type='" + result.getAt("seller_reputation").getAt("power_seller_status") + "' WHERE id_ml=" + id)
            }
            else if (response.getStatusLine().getStatusCode() == HttpStatus.SC_UNAUTHORIZED || response.getStatusLine().getStatusCode() == HttpStatus.SC_FORBIDDEN )
                throw new ApiException("executeListingSearch.failed","Failed to get ListingByCategoryAndQuery from mercadolibre api",HttpStatus.SC_INTERNAL_SERVER_ERROR);
        }
        catch(Exception e){

        }
    }


}

