package ecom

class BackTagLib {
    static defaultEncodeAs = [taglib:'html']
    static namespace = "ecom"
    def backButton = { attrs, body ->
        if(session.backHref != null)
            out << session.backHref
    }
}
