package ecom

import grails.test.mixin.TestFor
import org.junit.Test

import java.text.DateFormat
import java.text.SimpleDateFormat
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter


/**
 * See the API for {@link grails.test.mixin.services.ServiceUnitTestMixin} for usage instructions
 */
class CategoriesServiceSpec {

    def categoriesService

    def setup() {
    }

    def cleanup() {
    }

    @Test
    void "test something"() {

        DateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", Locale.getDefault());
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        Date date = simpleDateFormat.parse("2003-05-04T00:00:00.000-04:00");
        println date

    }
}
