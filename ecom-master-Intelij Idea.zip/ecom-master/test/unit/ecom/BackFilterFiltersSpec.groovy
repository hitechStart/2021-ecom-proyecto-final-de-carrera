package ecom

import grails.test.mixin.Mock
import spock.lang.Specification

@Mock(BackFilterFilters)
class BackFilterFiltersSpec extends Specification {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
    }
}
